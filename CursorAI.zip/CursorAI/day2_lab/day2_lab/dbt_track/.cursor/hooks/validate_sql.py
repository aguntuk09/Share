"""
Cursor afterFileEdit hook — SQL validation for the gen-staging-model lab.

Cursor spawns this script whenever the Agent writes or edits a file.
Input:  JSON object on stdin  (fields: file_path, edits, ...)
Output: JSON object on stdout (field: additional_context — shown in Agent chat)

Exit codes:
  0 = pass — Cursor uses the JSON output
  2 = block — Cursor denies the file write (not used here; we observe and report)
  other = hook failed — Cursor proceeds silently (fail-open)
"""
import json
import re
import sys
from pathlib import Path


def validate_sql(sql: str, file_path: str) -> list[str]:
    issues = []

    if re.search(r'\bSELECT\s+\*', sql, re.IGNORECASE):
        issues.append('SELECT * found — replace with an explicit column list')

    if re.search(r'\bCROSS\s+JOIN\b', sql, re.IGNORECASE):
        issues.append('CROSS JOIN found — verify this is intentional (cartesian product risk)')

    if re.search(r"'\d{4}-\d{2}-\d{2}'", sql):
        issues.append('Hardcoded date literal found — use CURRENT_DATE or a dbt variable')

    if re.search(r'\(\s*SELECT\b', sql, re.IGNORECASE):
        issues.append('Correlated/inline subquery found — convert to a CTE')

    if not re.search(r'\{\{\s*source\s*\(', sql, re.IGNORECASE):
        issues.append('Missing {{ source() }} macro — staging models must not reference raw tables directly')

    if re.search(r'<[a-z_]+>', sql, re.IGNORECASE):
        placeholders = re.findall(r'<[a-z_]+>', sql, re.IGNORECASE)
        unique = list(dict.fromkeys(placeholders))
        issues.append(f'Unreplaced template placeholders: {unique}')

    return issues


def main():
    #try:
    #    data = json.load(sys.stdin)
    #except json.JSONDecodeError as e:
    #    print(json.dumps({'additional_context': f'Hook error: could not parse input JSON — {e}'}))
    #    sys.exit(0)

    raw_bytes = b''
    try:
        raw_bytes = sys.stdin.buffer.read()
        if not raw_bytes.strip():
            data = {}
        else:
            data = json.loads(raw_bytes.decode('utf-8-sig'))
    except json.JSONDecodeError as exc:
        first_bytes = raw_bytes[:4].hex() if raw_bytes else 'empty'
        print(
            f'JSON decode failed: {exc}; first_bytes={first_bytes}',
            file=sys.stderr,
        )
        print(json.dumps({'additional_context': f'Hook error: could not parse input JSON — {exc}'}))
        sys.exit(0)



    file_path = data.get('file_path', '')

    # Only validate .sql files
    if not file_path.endswith('.sql'):
        sys.exit(0)

    # Read content from the edits field — file may not be saved to disk yet
    edits = data.get('edits', [])
    if edits:
        sql = edits[-1].get('new_string', '')
    else:
        # Fallback: try reading from disk
        path = Path(file_path)
        if not path.exists():
            sys.exit(0)
        sql = path.read_text(encoding='utf-8')

    issues = validate_sql(sql, file_path)

    if issues:
        lines = '\n'.join(f'  {i + 1}. {v}' for i, v in enumerate(issues))
        context = f'SQL validation — {len(issues)} issue(s) in {Path(file_path).name}:\n{lines}'
    else:
        context = f'SQL validation passed — {Path(file_path).name}'

    print(json.dumps({'additional_context': context}))
    sys.exit(0)


if __name__ == '__main__':
    main()
