"""
Post-generation validator for the gen-staging-model skill.
The skill's SKILL.md directs the Agent to run this after generating a .sql file.

Usage: python scripts/validate_output.py <sql_filepath>
Exit 0 = passes all checks
Exit 1 = one or more issues found
"""
import re
import sys
from pathlib import Path

CHECKS = [
    (r'\bSELECT\s+\*',
     'SELECT * found — use an explicit column list'),
    (r'\bCROSS\s+JOIN\b',
     'CROSS JOIN found — verify this is intentional (produces cartesian product)'),
    (r"'\d{4}-\d{2}-\d{2}'",
     'Hardcoded date literal found — use CURRENT_DATE or a dbt variable'),
    (r'\(\s*SELECT\b',
     'Correlated subquery found — convert to a CTE'),
    (r'dbt_utils\.generate_surrogate_key',
     None),  # presence check — must exist
]

REQUIRED_PATTERNS = [
    (r'\{\{\s*source\s*\(',
     'Missing {{ source() }} macro — staging models must reference source, not raw table strings'),
    (r'_fivetran_deleted\s*=\s*(false|FALSE)',
     'Missing _FIVETRAN_DELETED filter — staging models must exclude soft-deleted rows'),
]


def validate(filepath: str) -> list[str]:
    path = Path(filepath)
    if not path.exists():
        return [f'File not found: {filepath}']

    sql = path.read_text(encoding='utf-8')
    issues = []

    # Anti-pattern checks
    for pattern, message in CHECKS:
        if message and re.search(pattern, sql, re.IGNORECASE | re.DOTALL):
            issues.append(message)

    # Required pattern checks
    for pattern, message in REQUIRED_PATTERNS:
        if not re.search(pattern, sql, re.IGNORECASE):
            issues.append(message)

    # Check for placeholder text not replaced
    placeholders = re.findall(r'<[a-z_]+>', sql, re.IGNORECASE)
    if placeholders:
        unique = list(dict.fromkeys(placeholders))
        issues.append(f'Unreplaced template placeholders found: {unique}')

    return issues


def main():
    if len(sys.argv) < 2:
        print('Usage: python validate_output.py <sql_file>')
        sys.exit(1)

    filepath = sys.argv[1]
    issues = validate(filepath)

    if issues:
        print(f'Staging model validation — {len(issues)} issue(s) in {filepath}:')
        for i, issue in enumerate(issues, 1):
            print(f'  {i}. {issue}')
        sys.exit(1)
    else:
        print(f'Staging model validation — OK: {filepath}')
        sys.exit(0)


if __name__ == '__main__':
    main()
