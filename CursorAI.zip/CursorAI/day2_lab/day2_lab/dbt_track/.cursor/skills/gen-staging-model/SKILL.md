---
name: gen-staging-model
description: Generate a dbt staging model from a source table schema.
             Use when asked to create a staging model, build a stg_ layer,
             or transform a raw source table for the staging layer.
             Triggered by phrases like: "create staging model", "generate stg_",
             "build staging layer for this table".
---

## Workflow

1. Open `assets/stg_template.sql` — use it as the starting structure for the new model
2. Replace all `<placeholder>` values in the template with the actual source table, schema, and column names from the provided schema
3. For column naming conventions (snake_case, surrogate keys, boolean flags, date columns), consult `references/dbt_naming_conventions.md`
4. Adapt all casts, filters, and derived columns to match the actual source schema
5. After generating the `.sql` file, run the bundled validator:
   `python scripts/validate_output.py {generated_filepath}`
6. Fix any issues reported by the validator before finishing
7. Generate the accompanying `schema.yml` with:
   - One-sentence business-friendly model description
   - Column description for every column
   - `unique` + `not_null` tests on the surrogate key
   - `accepted_values` test on any status or type column
   - `relationships` test on any FK column
