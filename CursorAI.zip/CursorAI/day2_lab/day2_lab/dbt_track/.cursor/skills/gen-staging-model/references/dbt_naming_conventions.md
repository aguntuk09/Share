# dbt Naming Conventions Reference

Loaded on demand by the gen-staging-model skill.

## Model Layer Naming

| Layer | Prefix | Example |
|-------|--------|---------|
| Staging | `stg_<source>_<entity>` | `stg_raw_orders`, `stg_raw_customers` |
| Intermediate | `int_<description>` | `int_daily_order_totals` |
| Fact | `fct_<fact>` | `fct_orders`, `fct_daily_revenue` |
| Dimension | `dim_<entity>` | `dim_customers`, `dim_products` |

## Column Naming

- All column names: `snake_case` (never UPPER_CASE from source)
- Surrogate keys: `<entity>_sk` (e.g., `order_sk`, `customer_sk`)
- Foreign keys: `<entity>_id` (matches the referenced model's natural key)
- Boolean flags: `is_<condition>` or `has_<condition>` (e.g., `is_high_value`, `has_promo`)
- Date columns: `<event>_date` (e.g., `order_date`, `activation_date`)
- Timestamp columns: `<event>_at` (e.g., `created_at`, `updated_at`)

## Source Column Renames (common patterns)

| Source column pattern | Rename to |
|----------------------|-----------|
| `ORDER_ID` | `order_id` |
| `CUST_ID` | `customer_id` |
| `ORDER_DT` (string) | `order_date` (cast to DATE) |
| `CREATED_TS` | `created_at` |
| `AMT` / `AMOUNT` | `amount` |
| `IS_ACTIVE` (0/1) | `is_active` (cast to BOOLEAN) |
| `_FIVETRAN_SYNCED` | `fivetran_synced_at` |

## CTE Naming Pattern

Use verb-noun pattern describing what the CTE produces:

```sql
filtered_orders     -- filters the raw source
renamed_columns     -- applies snake_case renaming
derived_flags       -- adds calculated boolean columns
```

## Standard Filters in Staging

Always apply in staging, never in marts:
- `_FIVETRAN_DELETED = FALSE` — exclude soft-deleted rows
- `STATUS != 'TEST'` — exclude QA test records (if applicable)
