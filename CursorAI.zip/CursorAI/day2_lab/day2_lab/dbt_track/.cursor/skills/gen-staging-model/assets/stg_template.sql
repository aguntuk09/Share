-- dbt Staging Model Template
-- Skill: gen-staging-model | Replace all <placeholders> with actual values

WITH source AS (

    SELECT * FROM {{ source('<schema>', '<table_name>') }}

),

cleaned AS (

    SELECT
        -- Surrogate key (replace <pk_column> with the natural primary key)
        {{ dbt_utils.generate_surrogate_key(['<pk_column>']) }}  AS <entity>_sk,

        -- Natural primary key
        <pk_column>                                              AS <pk_column_snake>,

        -- FK columns (rename and cast as needed)
        -- <fk_column>                                          AS <fk_snake>,

        -- Date / timestamp columns (cast from STRING if needed)
        -- CAST(<date_column> AS DATE)                          AS <date_snake>,
        -- <ts_column>                                          AS <ts_snake>,

        -- Business columns (rename to snake_case)
        -- <COLUMN_NAME>                                        AS column_name,

        -- Derived boolean columns (add as needed)
        -- CASE WHEN <flag_column> = 1 THEN TRUE ELSE FALSE END AS is_<flag>,

        -- Metadata
        _fivetran_synced                                         AS fivetran_synced_at

    FROM source

    -- Standard filters — remove rows that should never reach analytics
    WHERE _fivetran_deleted = FALSE
      AND <status_column> != 'TEST'   -- remove QA test records if applicable

)

SELECT * FROM cleaned
