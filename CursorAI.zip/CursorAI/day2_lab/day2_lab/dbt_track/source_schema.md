# Source Table: `raw.orders`

Loaded nightly via Fivetran from the transactional database.

## Columns

| Column Name        | Type      | Nullable | Description |
|--------------------|-----------|----------|-------------|
| ORDER_ID           | STRING    | NO       | Primary key. Format: `ORD-XXXXXXXX` |
| CUST_ID            | STRING    | YES      | FK to customer table. NULL for guest checkouts |
| ORDER_DT           | STRING    | NO       | Order date stored as string: `YYYY-MM-DD` |
| UPDATED_AT         | TIMESTAMP | NO       | Last updated timestamp |
| AMT                | FLOAT64   | YES      | Order total in USD. NULL for draft orders |
| CURR               | STRING    | YES      | Currency code: `USD`, `EUR`, `GBP` |
| STATUS             | STRING    | NO       | One of: `pending`, `complete`, `cancelled`, `refunded`, `TEST` |
| REGION             | STRING    | YES      | `NORTH`, `SOUTH`, `EAST`, `WEST`, `INTERNATIONAL` |
| CHANNEL            | STRING    | YES      | `organic`, `paid`, `referral`, `direct` |
| PROMO_CODE         | STRING    | YES      | Promotional code used, if any |
| ITEM_COUNT         | INTEGER   | YES      | Number of line items |
| _FIVETRAN_DELETED  | BOOLEAN   | NO       | Soft delete flag |
| _FIVETRAN_SYNCED   | TIMESTAMP | NO       | Fivetran sync timestamp |

## Known Data Quality Issues

- `ORDER_DT` is STRING — must be cast to DATE
- `AMT` is NULL for draft orders (some `pending` rows)
- `STATUS = 'TEST'` rows are QA testing records — exclude from analytics
- Duplicate `ORDER_ID` values can appear briefly; deduplicate in staging
- `CUST_ID` is NULL for ~5% of rows (guest checkouts)
- `_FIVETRAN_DELETED = true` rows must be filtered out
