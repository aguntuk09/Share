"""
Cross-platform test runner for the validate_sql hook.
Simulates the JSON input Cursor sends on afterFileEdit.
Run: python test_hook.py
"""
import subprocess
import json
import sys
from pathlib import Path

# Read the test file content (simulates what Cursor puts in the edits field)
test_file = Path('test_sql_with_issues.sql')
source = test_file.read_text(encoding='utf-8') if test_file.exists() else 'SELECT * FROM raw.orders'

test_input = {
    "file_path": str(test_file.resolve()),
    "hook_event_name": "afterFileEdit",
    "edits": [
        {"old_string": "", "new_string": source}
    ]
}

result = subprocess.run(
    [sys.executable, '.cursor/hooks/validate_sql.py'],
    input=json.dumps(test_input),
    capture_output=True,
    text=True
)

print(result.stdout or '(no output)')
if result.stderr:
    print(f'stderr: {result.stderr}', file=sys.stderr)
