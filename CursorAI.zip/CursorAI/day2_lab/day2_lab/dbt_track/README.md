# Lab 2 — Stream A: Build a dbt-helper Cursor Plugin

**Duration:** 2 hours (14:00 – 16:00)  
**Stream:** Data Engineering (dbt + BigQuery SQL)

---

## What You Will Build

By the end of this lab, you will have built and verified all the following inside `labs/day2_lab/dbt_track/`, then packaged them into a distributable plugin:

```
labs/day2_lab/dbt_track/
├── .cursor/
│   ├── rules/
│   │   └── dbt_standards.mdc          ← Exercise 1: Always rule
│   ├── skills/
│   │   └── gen-staging-model/
│   │       ├── SKILL.md               ← Exercise 2: Skill
│   │       ├── assets/
│   │       ├── references/
│   │       └── scripts/
│   ├── hooks.json                     ← Exercise 3: Hook config
│   ├── hooks/
│   │   └── validate_sql.py            ← Exercise 3: Hook script
│   ├── agents/
│   │   └── dbt-reviewer.md            ← used in Exercise 4
│   └── mcp.json                       ← Exercise 5: MCP config
│
└── cursor-plugins/
    └── dbt-helper/                    ← Exercise 4: Distributable plugin
        ├── .cursor-plugin/
        │   └── plugin.json
        ├── rules/
        ├── skills/
        ├── hooks.json + hooks/
        ├── agents/
        ├── mcp/
        │   └── simple_mcp_server.py   ← bundled server (Exercise 5)
        ├── mcp.json                   ← references mcp/simple_mcp_server.py
        └── README.md
```

---

## Setup

1. Open `labs/day2_lab/dbt_track/` in Cursor — this is your workspace for the entire lab
2. Run: `pip install mcp`
3. The following starter files are **already provided** in this folder — you will customise them during the exercises:
   - `.cursor/rules/dbt_standards.mdc` — Always rule (Exercise 1)
   - `.cursor/skills/gen-staging-model/SKILL.md` — Skill with assets/references/scripts (Exercise 2)
   - `.cursor/hooks.json` + `.cursor/hooks/validate_sql.py` — Hook config and script (Exercise 3)
   - `.cursor/agents/dbt-reviewer.md` — Subagent (used in Exercise 4)
   - `cursor-plugins/dbt-helper/.cursor-plugin/plugin.json` — Plugin manifest (Exercise 4)

---

## Exercise 1: Always Rule — Coding Standards 

**Goal:** Create (or customise) the `dbt_standards.mdc` rule and verify it applies automatically.

1. Open `.cursor/rules/dbt_standards.mdc` — a starter file is already there
2. Read it, then use Cursor to improve it:
   ```
   Ctrl+L → "Review @.cursor/rules/dbt_standards.mdc.
              Are there any important dbt or BigQuery SQL standards missing?
              Suggest additions."
   ```
3. Update the rule with any improvements you agree with
4. **Test it:** Create a blank file `test_model.sql` in the root of `labs/day2_lab/dbt_track/`, then:
   ```
   Ctrl+I → "Write a SQL query that joins two tables and calculates a sum"
   ```
   Cursor should automatically use CTEs and BigQuery dialect — without you saying so.

5. **Verify the rule is loading:** Press `Ctrl+L` → ask "What rules are active for this session?"

---

## Exercise 2: Skill — Generate Staging Model 

**Goal:** Understand and customise the Cursor Skill already provided, then verify the Agent uses it automatically.

> **Skills vs Rules:** A Skill is a separate feature from Rules. It lives in `.cursor/skills/<name>/` as a folder with a `SKILL.md` file — not in `.cursor/rules/` as an `.mdc` file. Skills can also bundle scripts and templates alongside the instructions.

The skill folder and files are **already provided** at `.cursor/skills/gen-staging-model/`:
```
.cursor/skills/gen-staging-model/
├── SKILL.md               ← open and customise this
├── assets/stg_template.sql
├── references/dbt_naming_conventions.md
└── scripts/validate_output.py
```

1. Open `.cursor/skills/gen-staging-model/SKILL.md`, read the workflow, then customise it for this lab.

2. **Frontmatter reminder** — the `name` field must match the folder name exactly:

```markdown
---
name: gen-staging-model
description: Generate a dbt staging model from a source table schema.
             Use when asked to create a staging model, build a stg_ layer,
             or transform a raw source table for the staging layer.
---
```

3. **Test the skill — invoke automatically:**
   ```
   Ctrl+I (Agent mode) → "Create a staging model for raw.orders using @source_schema.md"
   ```
   The Agent discovers the skill from `.cursor/skills/` on startup and applies it when the task matches.

4. **Test the skill — invoke explicitly:**
   ```
   /gen-staging-model
   "Build a staging model for raw.orders using @source_schema.md"
   ```
   The `/skill-name` command forces the skill regardless of context inference.

5. If the output doesn't match your checklist, update `SKILL.md` and re-test.

---

## Exercise 3: Hook — SQL Validation After Generation 

**Goal:** Understand how the pre-configured hook works, verify it fires automatically when the Agent writes a `.sql` file, and optionally make it blocking.

> **Hooks are NOT rules.** A hook is configured in `.cursor/hooks.json` and runs as a Python process. Cursor spawns it at a defined agent loop event, passes event data as JSON on stdin, and reads results from stdout. The Agent has no role in triggering it — Cursor does.

### Part A: Understand the hook script

1. Open `.cursor/hooks/validate_sql.py` — it is already provided for this lab
2. Read through it — notice:
   - It reads `json.load(sys.stdin)` to get the `file_path`
   - It skips non-`.sql` files with `sys.exit(0)`
   - It returns `{"additional_context": "..."}` which is visible in **Cursor Settings → Hooks → Execution Log**
3. Run the test script (works on Windows cmd, PowerShell, Mac, and Linux):
   ```
   python test_hook.py
   ```
   > `test_hook.py` passes `test_sql_with_issues.sql` — a local SQL file containing intentional anti-patterns — to the hook and prints the JSON output.

   You should see issues reported: `SELECT *`, `CROSS JOIN`, hardcoded date literal, and `ORDER BY` positional reference.

### Part B: Configure `hooks.json`

Open `.cursor/hooks.json` — it is already configured:

```json
{
  "version": 1,
  "hooks": {
    "afterFileEdit": [
      {
        "command": "python .cursor/hooks/validate_sql.py"
      }
    ]
  }
}
```

The `afterFileEdit` event fires every time the Agent writes or edits any file. The hook script filters to `.sql` files internally.

### Part C: Trigger the hook

1. Press `Ctrl+I` (Agent mode)
2. Ask: "Generate a staging model for raw.orders using @source_schema.md. Use SELECT * for the column list."  
   *(deliberately introduce an anti-pattern)*
3. After the Agent writes the file, Cursor spawns the hook automatically
4. Open **Cursor Settings → Hooks → Execution Log** — you should see the hook output listing the SELECT * warning
5. The hook ran automatically — no rule or Agent instruction triggered it

### Part D: Make it blocking (optional)

Change `sys.exit(0)` to `sys.exit(2)` in the script when issues are found. Re-run the same prompt — the file write will be **blocked entirely** by Cursor before it lands on disk.

---

## Exercise 4: Plugin — Bundle and Share 

**Goal:** Package your Rule, Skill, Hook, and Subagent into a proper Cursor plugin with a manifest.

> **Plugin structure:** Components (`rules/`, `skills/`, `hooks.json`, `agents/`) sit at the **plugin root**, NOT inside `.cursor/`. The plugin has a `.cursor-plugin/plugin.json` manifest file. A starter manifest is already at `cursor-plugins/dbt-helper/.cursor-plugin/plugin.json`.

1. The target structure is:
   ```
   cursor-plugins/dbt-helper/
   ├── .cursor-plugin/
   │   └── plugin.json          ← manifest (already created)
   ├── rules/
   │   └── dbt_standards.mdc    ← copy from .cursor/rules/
   ├── skills/
   │   └── gen-staging-model/   ← copy from .cursor/skills/
   ├── agents/
   │   └── dbt-reviewer.md      ← copy from .cursor/agents/
   ├── hooks.json               ← copy from .cursor/hooks.json
   ├── hooks/
   │   └── validate_sql.py      ← copy from .cursor/hooks/
   └── README.md
   ```

2. Copy your components into the plugin folder using the Agent:
   ```
   Ctrl+I → "Copy .cursor/rules/dbt_standards.mdc to cursor-plugins/dbt-helper/rules/,
              .cursor/skills/gen-staging-model/ to cursor-plugins/dbt-helper/skills/,
              .cursor/agents/dbt-reviewer.md to cursor-plugins/dbt-helper/agents/,
              .cursor/hooks.json to cursor-plugins/dbt-helper/hooks.json,
              .cursor/hooks/validate_sql.py to cursor-plugins/dbt-helper/hooks/,
              labs/day2_lab/shared/simple_mcp_server.py to cursor-plugins/dbt-helper/mcp/"
   ```

3. Generate the README:
   ```
   Ctrl+I → "Write a README.md for cursor-plugins/dbt-helper/ that explains:
              what each component does (rule, skill, hook, subagent),
              how to install locally (copy to ~/.cursor/plugins/local/dbt-helper/),
              and what validate_sql.py checks for"
   ```

4. **Test local install:**
   - Copy `cursor-plugins/dbt-helper/` to:
     - **Mac/Linux:** `~/.cursor/plugins/local/dbt-helper/`
     - **Windows:** `%USERPROFILE%\.cursor\plugins\local\dbt-helper\`
   - Reload Cursor: `Ctrl+Shift+P` → "Developer: Reload Window"
   - Open a fresh folder, ask "Generate a staging model" — the plugin's Rule, Skill, and Hook should all activate

---

## Exercise 5: MCP Server — Use Local Tools 

**Goal:** Configure the local MCP server and use it to read schema data from within Cursor chat.

> **stdio transport:** Cursor **auto-launches** the Python server when it reads `mcp.json`. You do NOT need to manually run `python server.py`. Cursor manages the process — starting it on launch, restarting it if it crashes.

### Part A: Set up the MCP server

1. Install the MCP package (one-time):
   ```
   pip install mcp
   ```
2. Create `.cursor/mcp.json` inside `labs/day2_lab/dbt_track/`:
   ```json
   {
     "mcpServers": {
       "local-tools": {
         "command": "python",
         "args": ["../shared/simple_mcp_server.py"],
         "env": {}
       }
     }
   }
   ```
   > The path `../shared/simple_mcp_server.py` is relative to this workspace root (`labs/day2_lab/dbt_track/`). It points one level up to `labs/day2_lab/shared/`.
3. Restart Cursor — it reads `mcp.json` and spawns the Python process automatically
4. Verify: Cursor Settings → MCP — `local-tools` should show as connected

### Part B: Use the tools

1. Test tool 1 — the MCP server reads `source_schema.md` from the workspace root:
   ```
   Ctrl+L → "Use the read_schema tool with the argument 'source_schema' to fetch the orders table definition"
   ```
   > Be explicit about the argument name `source_schema` — this matches the filename `source_schema.md` that the MCP server will read.
   
   (Cursor calls `read_schema("source_schema")`, which reads `labs/day2_lab/dbt_track/source_schema.md` and returns the column definitions)

2. Test tool 2:
   ```
   Ctrl+L → "Use list_project_files to show me all SQL files in this project"
   ```

3. Combine MCP + Skill:
   ```
   Ctrl+I → "Use the read_schema tool with argument 'source_schema' to fetch the table definition,
              then generate a staging model for it.
              I don't want to paste the schema manually."
   ```

### Part C: Add MCP config to your plugin

Do **not** copy `.cursor/mcp.json` directly — its path (`../shared/simple_mcp_server.py`) is relative to this lab folder and will break after the plugin is installed elsewhere.

Instead, create a new `cursor-plugins/dbt-helper/mcp.json` that references the bundled server:

```json
{
  "mcpServers": {
    "local-tools": {
      "command": "python",
      "args": ["mcp/simple_mcp_server.py"],
      "env": {}
    }
  }
}
```

> `mcp/simple_mcp_server.py` is a path relative to the plugin root — it points to the copy you bundled in step 2 above. After the plugin is installed at `~/.cursor/plugins/local/dbt-helper/`, this path resolves correctly.

---


