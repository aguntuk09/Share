-- Test SQL file containing intentional anti-patterns.
-- Used to verify the validate_sql hook catches issues correctly.

SELECT *
FROM raw.orders o
CROSS JOIN raw.customers c
WHERE o.order_date >= '2024-01-01'
  AND o.status != 'TEST'
GROUP BY
    SUBSTR(o.order_date, 1, 7),
    c.region
ORDER BY 1, 2
