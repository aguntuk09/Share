"""
Test Python file containing intentional style issues.
Used to verify the format_check_hook catches issues correctly.
"""
import pandas as pd


def load_data(path):
    df = pd.read_csv(path)
    print(f"Loaded {len(df)} rows")
    return df


def clean_records(df):
    try:
        df = df[df["status"] == "complete"]
    except:
        pass
    return df


def calculate_totals(df):
    result = df.groupby("region").agg(total=("amount", "sum")).reset_index()
    print(result)
    return result


def run():
    df = load_data("data.csv")
    df = clean_records(df)
    totals = calculate_totals(df)
    totals.to_csv("output.csv")
