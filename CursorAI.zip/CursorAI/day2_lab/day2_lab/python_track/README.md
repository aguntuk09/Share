# Lab 2 — Stream B: Build a python-helper Cursor Plugin

**Duration:** 2 hours (14:00 – 16:00)  
**Stream:** Support & Automation (Python)

---

## What You Will Build

By the end of this lab, you will have built and verified all the following inside `labs/day2_lab/python_track/`, then packaged them into a distributable plugin:

```
labs/day2_lab/python_track/
├── .cursor/
│   ├── rules/
│   │   └── python_standards.mdc       ← Exercise 1: Always rule
│   ├── skills/
│   │   └── gen-data-script/
│   │       ├── SKILL.md               ← Exercise 2: Skill
│   │       ├── assets/
│   │       └── scripts/
│   ├── hooks.json                     ← Exercise 3: Hook config
│   ├── hooks/
│   │   └── format_check_hook.py       ← Exercise 3: Hook script
│   ├── agents/
│   │   └── test-writer.md             ← used in Exercise 4
│   └── mcp.json                       ← Exercise 5: MCP config
│
└── cursor-plugins/
    └── python-helper/                 ← Exercise 4: Distributable plugin
        ├── .cursor-plugin/
        │   └── plugin.json
        ├── rules/
        ├── skills/
        ├── hooks.json + hooks/
        ├── agents/
        ├── mcp/
        │   └── simple_mcp_server.py   ← bundled server (Exercise 5)
        ├── mcp.json                   ← references mcp/simple_mcp_server.py
        └── README.md
```

---

## Setup

1. Open `labs/day2_lab/python_track/` in Cursor — this is your workspace for the entire lab
2. Run: `pip install mcp`
3. The following starter files are **already provided** in this folder — you will customise them during the exercises:
   - `.cursor/rules/python_standards.mdc` — Always rule (Exercise 1)
   - `.cursor/skills/gen-data-script/SKILL.md` — Skill with assets/scripts (Exercise 2)
   - `.cursor/hooks.json` + `.cursor/hooks/format_check_hook.py` — Hook config and script (Exercise 3)
   - `.cursor/agents/test-writer.md` — Subagent (used in Exercise 4)
   - `cursor-plugins/python-helper/.cursor-plugin/plugin.json` — Plugin manifest (Exercise 4)

---

## Exercise 1: Always Rule — Python Standards 

**Goal:** Customise the `python_standards.mdc` rule and verify it applies automatically.

1. Open `.cursor/rules/python_standards.mdc` — a starter file is already there
2. Use Cursor to review and improve it:
   ```
   Ctrl+L → "Review @.cursor/rules/python_standards.mdc.
              Based on what a Python automation team needs,
              what important standards are missing? Suggest additions."
   ```
3. Add any improvements you agree with
4. **Test it:** Create a blank file `test_script.py`, then:
   ```
   Ctrl+I → "Write a function that reads a CSV file and returns a summary"
   ```
   The output should have type hints, use `logging`, use `pathlib.Path`, and avoid `print()` — without you asking for any of that.



---

## Exercise 2: Skill — Generate Data Processing Script 

**Goal:** Understand and customise the Cursor Skill already provided, then verify the Agent uses it automatically.

> **Skills vs Rules:** A Skill lives in `.cursor/skills/<name>/` as a folder with a `SKILL.md` file — not in `.cursor/rules/`. Skills are a separate feature that can also bundle scripts and templates alongside the instructions.

The skill folder and files are **already provided** at `.cursor/skills/gen-data-script/`:
```
.cursor/skills/gen-data-script/
├── SKILL.md               ← open and customise this
├── assets/script_template.py
└── scripts/format_check.py
```

1. Open `.cursor/skills/gen-data-script/SKILL.md`, read the workflow, then customise it for this lab.

2. **Frontmatter reminder** — the `name` field must match the folder name exactly:

```markdown
---
name: gen-data-script
description: Generate a Python data processing script. Use when asked to create
             a script that reads, cleans, transforms, or summarises data files.
---
```

3. **Test the skill — invoke automatically:**
   ```
   Ctrl+I (Agent mode) → "Create a script that reads sales_data.csv,
                           filters to only 'complete' sales,
                           and saves a regional summary"
   ```
   The Agent discovers the skill from `.cursor/skills/` on startup and applies it when the task matches.

4. **Test the skill — invoke explicitly:**
   ```
   /gen-data-script
   "Create a script that reads sales_data.csv and saves a regional summary"
   ```
   The `/skill-name` command forces the skill regardless of context inference.

5. If the output doesn't match your checklist, update `SKILL.md` and re-test.

---

## Exercise 3: Hook — Style Check After Generation 

**Goal:** Understand how the pre-configured hook works, verify it fires automatically when the Agent writes a `.py` file, and optionally make it blocking.

> **Hooks are configured in `hooks.json`**, not in `.cursor/rules/`. The script receives event data as JSON on stdin, runs checks, and returns `additional_context` on stdout. The output is visible in **Cursor Settings → Hooks → Execution Log**.

### Part A: Understand the hook script

1. Open `.cursor/hooks/format_check_hook.py` — already provided for this lab
2. Read through it — notice:
   - It reads `json.load(sys.stdin)` to get the `file_path`
   - It skips non-`.py` files with `sys.exit(0)`
   - It checks for `print(` in the file content
   - It returns `{"additional_context": "..."}` — visible in **Cursor Settings → Hooks → Execution Log**
3. Run the test script (works on Windows cmd, PowerShell, Mac, and Linux):
   ```
   python test_hook.py
   ```
   > `test_hook.py` passes `test_py_with_issues.py` — a local Python file containing intentional style issues — to the hook and prints the JSON output.

   You should see issues reported: `print()` calls, bare `except:` clauses, and missing type hints.

### Part B: Review `hooks.json`

Open `.cursor/hooks.json` — it is already configured:

```json
{
  "version": 1,
  "hooks": {
    "afterFileEdit": [
      {
        "command": "python .cursor/hooks/format_check_hook.py"
      }
    ]
  }
}
```

`afterFileEdit` fires whenever the Agent writes any file. The hook filters to `.py` files internally.

### Part C: Trigger the hook

1. Press `Ctrl+I` (Agent mode)
2. Ask: "Generate a script that reads a CSV and prints a summary to the console"  
   *(the word "prints" will likely cause the Agent to use `print()`)*
3. After the file is written, Cursor spawns the hook automatically
4. Open **Cursor Settings → Hooks → Execution Log** — you should see the hook output reporting the `print()` issue
5. The hook ran automatically — no rule or Agent instruction triggered it

### Part D: Make it blocking (optional)

Change `sys.exit(0)` to `sys.exit(2)` when issues exist. Re-run — the file write is **blocked** before it lands on disk.

---

## Exercise 4: Plugin — Bundle and Share 

**Goal:** Package your Rule, Skill, Hook, and Subagent into a proper Cursor plugin with a manifest.

> **Plugin structure:** Components (`rules/`, `skills/`, `hooks.json`, `agents/`) sit at the **plugin root** — not inside `.cursor/`. A starter manifest is at `cursor-plugins/python-helper/.cursor-plugin/plugin.json`.

1. The target structure is:
   ```
   cursor-plugins/python-helper/
   ├── .cursor-plugin/
   │   └── plugin.json              ← manifest (already created)
   ├── rules/
   │   └── python_standards.mdc     ← copy from .cursor/rules/
   ├── skills/
   │   └── gen-data-script/         ← copy from .cursor/skills/
   ├── agents/
   │   └── test-writer.md           ← copy from .cursor/agents/
   ├── hooks.json                   ← copy from .cursor/hooks.json
   ├── hooks/
   │   └── format_check_hook.py     ← copy from .cursor/hooks/
   └── README.md
   ```

2. Copy your components using the Agent:
   ```
   Ctrl+I → "Copy .cursor/rules/python_standards.mdc to cursor-plugins/python-helper/rules/,
              .cursor/skills/gen-data-script/ to cursor-plugins/python-helper/skills/,
              .cursor/agents/test-writer.md to cursor-plugins/python-helper/agents/,
              .cursor/hooks.json to cursor-plugins/python-helper/hooks.json,
              .cursor/hooks/format_check_hook.py to cursor-plugins/python-helper/hooks/,
              labs/day2_lab/shared/simple_mcp_server.py to cursor-plugins/python-helper/mcp/"
   ```

3. Generate the README:
   ```
   Ctrl+I → "Write a README.md for cursor-plugins/python-helper/ that explains:
              what each component does (rule, skill, hook, subagent),
              how to install locally (copy to ~/.cursor/plugins/local/python-helper/),
              and what format_check_hook.py checks for"
   ```

4. **Test local install:**
   - Copy `cursor-plugins/python-helper/` to:
     - **Mac/Linux:** `~/.cursor/plugins/local/python-helper/`
     - **Windows:** `%USERPROFILE%\.cursor\plugins\local\python-helper\`
   - Reload Cursor: `Ctrl+Shift+P` → "Developer: Reload Window"
   - Open a fresh folder, ask "Write a function to process a CSV" — the plugin's Rule, Skill, and Hook should all activate

---

## Exercise 5: MCP Server — Use Local Tools 

**Goal:** Configure the local MCP server and use its tools from within Cursor chat.

> **stdio transport:** Cursor **auto-launches** the Python server when it reads `mcp.json`. You do NOT need to manually run `python server.py`.

### Part A: Set up the MCP server

1. Install the MCP package (one-time):
   ```
   pip install mcp
   ```
2. Create `.cursor/mcp.json` inside `labs/day2_lab/python_track/`:
   ```json
   {
     "mcpServers": {
       "local-tools": {
         "command": "python",
         "args": ["../shared/simple_mcp_server.py"],
         "env": {}
       }
     }
   }
   ```
   > The path `../shared/simple_mcp_server.py` is relative to this workspace root (`labs/day2_lab/python_track/`). It points one level up to `labs/day2_lab/shared/`.
3. Restart Cursor — it reads `mcp.json` and spawns the Python process automatically
4. Verify connection: Cursor Settings → MCP — `local-tools` should show connected

### Part B: Use the tools

1. Test tool 1 (list files):
   ```
   Ctrl+L → "Use list_project_files to show me all .py files in this project"
   ```

3. Test tool 2 (read schema — works with any .md file):
   ```
   Ctrl+L → "Use read_schema to read the 'python_standards' file
              and summarise the key rules in bullet points"
   ```

4. Combine MCP + Skill:
   ```
   Ctrl+I → "Use list_project_files to find all .py files.
              Then review each one to check which ones are missing type hints."
   ```

### Part C: Add MCP config to your plugin

Do **not** copy `.cursor/mcp.json` directly — its path (`../shared/simple_mcp_server.py`) is relative to this lab folder and will break after the plugin is installed elsewhere.

Instead, create a new `cursor-plugins/python-helper/mcp.json` that references the bundled server:

```json
{
  "mcpServers": {
    "local-tools": {
      "command": "python",
      "args": ["mcp/simple_mcp_server.py"],
      "env": {}
    }
  }
}
```

> `mcp/simple_mcp_server.py` is a path relative to the plugin root — it points to the copy you bundled in step 2 above. After the plugin is installed at `~/.cursor/plugins/local/python-helper/`, this path resolves correctly.

---

