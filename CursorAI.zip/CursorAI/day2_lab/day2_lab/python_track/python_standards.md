# Python Coding Standards

Reference file for the local MCP server — read via `read_schema("python_standards")`.

## Code Style
- Python 3.11+
- Type hints required on all function signatures (args and return type)
- Max function length: 30 lines — split if longer
- Descriptive variable names — not `df2`, `temp`, `x`
- Constants in UPPER_CASE at module level

## Logging & Output
- Use `logging` module — never `print()`
- Add at module level: `logger = logging.getLogger(__name__)`
- Log at INFO for progress, WARNING for data issues, ERROR for failures
- Log row counts: `logger.info(f"Loaded {len(df)} rows from {filepath}")`

## Error Handling
- Never use bare `except:` — always catch specific exception types
- Re-raise with context: `raise ValueError(f"Missing column: {col}") from e`

## File & I/O
- File paths as `pathlib.Path` objects — not string concatenation
- `index=False` in `DataFrame.to_csv()` unless index is meaningful
- Check file existence before reading
- `output_path.parent.mkdir(parents=True, exist_ok=True)` before writing

## Entry Point
- All scripts must end with `if __name__ == "__main__":`
- Use `argparse` for command-line arguments

## Function Naming
- Use verb_noun pattern: `read_data`, `clean_records`, `calculate_summary`
- One function per responsibility
