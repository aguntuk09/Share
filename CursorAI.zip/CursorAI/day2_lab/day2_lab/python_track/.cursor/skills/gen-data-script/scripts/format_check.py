"""
Python style checker for the Cursor Hook exercise.
Uses only the standard library (ast, tokenize) — no external packages needed.

Checks for:
- Missing type hints on function definitions
- print() calls (should use logging)
- Bare except: clauses
- Missing if __name__ == "__main__": guard in scripts

Usage: python format_check.py <python_filepath>
Exit 0 = all checks passed
Exit 1 = one or more issues found
"""
import ast
import sys
import tokenize
import io
from pathlib import Path


def check_missing_type_hints(tree: ast.AST) -> list[str]:
    issues = []
    for node in ast.walk(tree):
        if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
            args = node.args
            all_args = (
                args.args + args.posonlyargs + args.kwonlyargs
                + ([args.vararg] if args.vararg else [])
                + ([args.kwarg] if args.kwarg else [])
            )
            for arg in all_args:
                if arg.arg == "self" or arg.arg == "cls":
                    continue
                if arg.annotation is None:
                    issues.append(
                        f"Line {node.lineno}: function '{node.name}' — "
                        f"argument '{arg.arg}' missing type hint"
                    )
            if node.returns is None and node.name != "__init__":
                issues.append(
                    f"Line {node.lineno}: function '{node.name}' — missing return type hint"
                )
    return issues


def check_print_statements(tree: ast.AST) -> list[str]:
    issues = []
    for node in ast.walk(tree):
        if isinstance(node, ast.Call):
            if isinstance(node.func, ast.Name) and node.func.id == "print":
                issues.append(
                    f"Line {node.lineno}: print() found — use logging.info() instead"
                )
    return issues


def check_bare_except(tree: ast.AST) -> list[str]:
    issues = []
    for node in ast.walk(tree):
        if isinstance(node, ast.ExceptHandler):
            if node.type is None:
                issues.append(
                    f"Line {node.lineno}: bare 'except:' found — "
                    "catch a specific exception type"
                )
    return issues


def check_main_guard(tree: ast.AST, source: str) -> list[str]:
    # Only warn for scripts (files with top-level executable code)
    has_functions = any(isinstance(n, (ast.FunctionDef, ast.AsyncFunctionDef)) for n in ast.walk(tree))
    has_classes = any(isinstance(n, ast.ClassDef) for n in ast.walk(tree))
    if not (has_functions or has_classes):
        return []

    has_main_guard = any(
        isinstance(node, ast.If)
        and isinstance(node.test, ast.Compare)
        and isinstance(node.test.left, ast.Name)
        and node.test.left.id == "__name__"
        for node in ast.walk(tree)
    )

    if not has_main_guard and ("def main" in source or "def run" in source):
        return ['File has a main/run function but no "if __name__ == "__main__":" guard']
    return []


def format_check(filepath: str) -> list[str]:
    path = Path(filepath)
    if not path.exists():
        return [f"File not found: {filepath}"]

    source = path.read_text(encoding="utf-8")

    try:
        tree = ast.parse(source, filename=filepath)
    except SyntaxError as e:
        return [f"Syntax error: {e}"]

    issues = []
    issues.extend(check_print_statements(tree))
    issues.extend(check_bare_except(tree))
    issues.extend(check_missing_type_hints(tree))
    issues.extend(check_main_guard(tree, source))
    return issues


def main():
    if len(sys.argv) < 2:
        print("Usage: python format_check.py <python_file>")
        sys.exit(1)

    filepath = sys.argv[1]
    issues = format_check(filepath)

    if issues:
        print(f"Style Check — {len(issues)} issue(s) found in {filepath}:")
        for i, issue in enumerate(issues, 1):
            print(f"  {i}. {issue}")
        sys.exit(1)
    else:
        print(f"Style Check — OK: {filepath}")
        sys.exit(0)


if __name__ == "__main__":
    main()
