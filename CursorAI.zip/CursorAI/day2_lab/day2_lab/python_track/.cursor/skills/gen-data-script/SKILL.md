---
name: gen-data-script
description: Generate a Python data processing script. Use when asked to create
             a script that reads, cleans, transforms, filters, or summarises
             data files. Triggered by: "build a script to", "write code that
             processes", "create a Python program that reads".
---

## Workflow

1. Open `assets/script_template.py` — use it as the starting structure
2. Replace all `<placeholder>` comments with actual logic for the requested task:
   - `read_data`: adapt for the actual input format and file path
   - `clean_data`: implement the specific filtering and cleaning rules
   - `transform_data`: implement the calculations or aggregations needed
   - `save_output`: adapt for the required output format
3. Rename functions if needed to match the task (e.g., `calculate_revenue`, `summarise_by_region`)
4. After generating the `.py` file, run the bundled style checker:
   `python scripts/format_check.py {generated_filepath}`
5. Fix any issues reported (missing type hints, `print()` calls, bare `except`, missing `__main__` guard)
6. Confirm the argparse entry point is present and matches the function signatures
