"""
Python Data Processing Script Template
Skill: gen-data-script | Replace all <placeholders> and adapt logic to the task.
"""
import argparse
import logging
from pathlib import Path

import pandas as pd

logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s [%(levelname)s] %(message)s'
)
logger = logging.getLogger(__name__)


def read_data(filepath: Path) -> pd.DataFrame:
    """Read input data from <filepath>."""
    if not filepath.exists():
        raise FileNotFoundError(f'Input file not found: {filepath}')
    df = pd.read_csv(filepath)
    logger.info(f'Loaded {len(df)} rows from {filepath}')
    return df


def clean_data(df: pd.DataFrame) -> pd.DataFrame:
    """Apply cleaning rules: <describe what this does>."""
    # TODO: replace with actual cleaning logic
    # Example: df = df[df['status'] == 'complete']
    logger.info(f'After cleaning: {len(df)} rows')
    return df


def transform_data(df: pd.DataFrame) -> pd.DataFrame:
    """Apply transformations: <describe what this does>."""
    # TODO: replace with actual transformation logic
    # Example: df['revenue'] = df['quantity'] * df['unit_price']
    logger.info(f'After transform: {len(df)} rows')
    return df


def save_output(df: pd.DataFrame, filepath: Path) -> None:
    """Save output to <filepath>."""
    filepath.parent.mkdir(parents=True, exist_ok=True)
    df.to_csv(filepath, index=False)
    logger.info(f'Saved {len(df)} rows to {filepath}')


def run(input_path: Path, output_path: Path) -> None:
    """Orchestrate the full pipeline."""
    df = read_data(input_path)
    df = clean_data(df)
    df = transform_data(df)
    save_output(df, output_path)


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description='<describe the script purpose>')
    parser.add_argument('input', type=Path, help='Path to input CSV')
    parser.add_argument('output', type=Path, help='Path to output CSV')
    args = parser.parse_args()
    run(args.input, args.output)
