"""
Cursor afterFileEdit hook — checks for print() in Python files.

Cursor spawns this script whenever the Agent writes or edits a file.
Input:  JSON on stdin  (fields: file_path, edits, ...)
Output: JSON on stdout (field: additional_context — shown in Agent chat)

Content is read from the 'edits' field in the JSON input — NOT from disk —
because the file may not be saved yet when the hook fires.
"""
import json
import sys
from pathlib import Path

raw_bytes = b''
try:
    raw_bytes = sys.stdin.buffer.read()
    if not raw_bytes.strip():
        data = {}
    else:
        data = json.loads(raw_bytes.decode('utf-8-sig'))
except json.JSONDecodeError as exc:
    first_bytes = raw_bytes[:4].hex() if raw_bytes else 'empty'
    print(
        f'JSON decode failed: {exc}; first_bytes={first_bytes}',
        file=sys.stderr,
    )
    print(json.dumps({'additional_context': f'Hook error: could not parse input JSON — {exc}'}))
    sys.exit(0)

file_path = data.get('file_path', '')

# Only check .py files
if not file_path.endswith('.py'):
    sys.exit(0)

# Read the new file content from the edits field (always available, no disk read needed)
edits = data.get('edits', [])
if not edits:
    sys.exit(0)

source = edits[-1].get('new_string', '')

filename = Path(file_path.replace('\\', '/')).name

if 'print(' in source:
    msg = f'Hook triggered: print() found in {filename} — use logging.info() instead.'
else:
    msg = f'Hook triggered: {filename} looks clean — no print() calls found.'

print(json.dumps({'additional_context': msg}))
sys.exit(0)
