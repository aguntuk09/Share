# MCP Setup Guide (Python only — no Node.js required)

---

## How `stdio` Transport Works

For local Python MCP servers, Cursor uses **stdio transport** — Cursor reads the `mcp.json` config and **automatically launches the Python process itself**. You do NOT need to manually run `python server.py`. Cursor manages the server lifecycle: starts it on launch, restarts it if it crashes.

This is different from HTTP/SSE transport, where you would deploy a server yourself and Cursor would connect to its URL.

---

## Step 1: Install the MCP package

```bash
pip install mcp
```

That's the only dependency. Verify:
```bash
python -c "import mcp; print('mcp installed OK')"
```

---

## Step 2: Configure Cursor

Create (or open) `.cursor/mcp.json` in your project root:

```json
{
  "mcpServers": {
    "local-tools": {
      "command": "python",
      "args": ["PATH_TO/labs/day2_lab/shared/simple_mcp_server.py"],
      "env": {}
    }
  }
}
```

**Replace `PATH_TO`** with the actual path to your training folder. On Windows, use forward slashes:

```json
"args": ["C:/Users/YourName/cursor_training/labs/day2_lab/shared/simple_mcp_server.py"]
```

The `command` and `args` tell Cursor how to spawn the server — Cursor handles starting and stopping it.

---

## Step 3: Restart Cursor

Reload the window: `Ctrl+Shift+P` → "Developer: Reload Window".  
Cursor reads `mcp.json` and spawns the Python process automatically — no manual start needed.

---

## Step 4: Verify the connection

1. Open Cursor Settings → MCP
2. You should see `local-tools` listed with a green dot (connected)
3. If it shows red/disconnected: check the file path in `mcp.json`

---

## Step 5: Test it in a prompt

Press `Ctrl+L` and type:
```
Use the list_project_files tool to list all .sql files in this project
```

Cursor should call the MCP tool and show a list of `.sql` files.

Try also:
```
Use read_schema to get the schema for the "source_schema" table
```
(This reads `source_schema.md` from the current directory.)

---

## Troubleshooting

| Problem | Fix |
|---------|-----|
| MCP shows as disconnected | Check file path in mcp.json — must be absolute path |
| `ModuleNotFoundError: mcp` | Run `pip install mcp` in the same Python environment Cursor uses |
| Tool not found in chat | Restart Cursor after editing mcp.json |
| `FileNotFoundError` on schema read | Make sure the `.md` file is in the current working directory |

---

## What the tools do

| Tool | How to invoke | What it returns |
|------|--------------|----------------|
| `read_schema(table_name)` | "Read the schema for orders" | Contents of `orders.md` from cwd |
| `list_project_files(extension)` | "List all .py files" | Relative paths of all matching files |
