"""
Local MCP server for Cursor training labs.
Exposes two tools: read_schema and list_project_files.

Install:   pip install mcp
Run:       python simple_mcp_server.py
Configure: add to .cursor/mcp.json (see mcp_setup_guide.md)
"""
import os
import sys
from pathlib import Path
from mcp.server import Server
from mcp.server.stdio import stdio_server
from mcp import types


server = Server("local-training-tools")


@server.list_tools()
async def list_tools() -> list[types.Tool]:
    return [
        types.Tool(
            name="read_schema",
            description=(
                "Read the schema definition for a database table. "
                "Looks for a markdown file named <table_name>.md in the current directory."
            ),
            inputSchema={
                "type": "object",
                "properties": {
                    "table_name": {
                        "type": "string",
                        "description": "Name of the table (without .md extension)",
                    }
                },
                "required": ["table_name"],
            },
        ),
        types.Tool(
            name="list_project_files",
            description=(
                "List all files with a given extension in the current working directory "
                "and its subdirectories."
            ),
            inputSchema={
                "type": "object",
                "properties": {
                    "extension": {
                        "type": "string",
                        "description": "File extension to search for (e.g. 'sql', 'py', 'yml')",
                    }
                },
                "required": ["extension"],
            },
        ),
    ]


@server.call_tool()
async def call_tool(name: str, arguments: dict) -> list[types.TextContent]:
    if name == "read_schema":
        table_name = arguments["table_name"]
        schema_file = Path(f"{table_name}.md")

        if not schema_file.exists():
            # also try in a schemas/ subfolder
            schema_file = Path("schemas") / f"{table_name}.md"

        if schema_file.exists():
            content = schema_file.read_text(encoding="utf-8")
            return [types.TextContent(type="text", text=content)]
        else:
            return [
                types.TextContent(
                    type="text",
                    text=f"Schema file not found: {table_name}.md\n"
                    f"Looked in: {Path.cwd()} and {Path.cwd() / 'schemas'}",
                )
            ]

    elif name == "list_project_files":
        ext = arguments["extension"].lstrip(".")
        cwd = Path.cwd()
        matches = sorted(cwd.rglob(f"*.{ext}"))

        if matches:
            file_list = "\n".join(str(f.relative_to(cwd)) for f in matches)
            return [
                types.TextContent(
                    type="text",
                    text=f"Found {len(matches)} .{ext} file(s):\n{file_list}",
                )
            ]
        else:
            return [
                types.TextContent(
                    type="text", text=f"No .{ext} files found in {cwd}"
                )
            ]

    return [types.TextContent(type="text", text=f"Unknown tool: {name}")]


async def main():
    async with stdio_server() as (read_stream, write_stream):
        await server.run(read_stream, write_stream, server.create_initialization_options())


if __name__ == "__main__":
    import asyncio
    asyncio.run(main())
