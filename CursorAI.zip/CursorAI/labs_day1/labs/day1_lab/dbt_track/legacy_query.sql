-- Legacy monthly revenue report — written 2021, never refactored
-- Known to be slow on large datasets

SELECT
    SUBSTR(ORDER_DT, 1, 7) AS month,
    (SELECT REGION FROM raw.orders o2 WHERE o2.ORDER_ID = o.ORDER_ID) AS region,
    SUM(AMT) AS total_revenue,
    COUNT(*) AS order_count,
    SUM(AMT) / COUNT(*) AS avg_order_value,
    (
        SELECT COUNT(*)
        FROM raw.orders o3
        WHERE SUBSTR(o3.ORDER_DT, 1, 7) = SUBSTR(o.ORDER_DT, 1, 7)
          AND o3.STATUS = 'complete'
          AND o3.REGION = (SELECT REGION FROM raw.orders o4 WHERE o4.ORDER_ID = o.ORDER_ID)
    ) AS complete_orders
FROM raw.orders o
WHERE STATUS != 'TEST'
  AND STATUS != 'cancelled'
  AND AMT IS NOT NULL
  AND AMT > 0
  AND ORDER_DT >= '2023-01-01'
  AND ORDER_DT < '2024-01-01'
  AND _FIVETRAN_DELETED = false
GROUP BY
    SUBSTR(ORDER_DT, 1, 7),
    (SELECT REGION FROM raw.orders o2 WHERE o2.ORDER_ID = o.ORDER_ID)
ORDER BY 1, 2
