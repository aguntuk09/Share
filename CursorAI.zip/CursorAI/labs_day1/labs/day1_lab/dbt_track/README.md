# Lab 1 — Stream A: dbt/SQL with Cursor Modes

**Duration:** 2 hours (14:00 – 16:00)  
**Stream:** Data Engineering (dbt + BigQuery SQL)

---

## Overview

You will use all five Cursor modes on real dbt/SQL tasks. Each exercise is mapped to a specific mode so you practice using the right tool for the right job.

| Exercise | Mode | Task | Time |
|----------|------|------|------|
| 0 | **Prompt Practice** | Rewrite weak prompts using the four-part formula | 15 min |
| 1 | **Ask** | Understand the source schema and legacy query | 10 min |
| 2 | **Agent** | Generate a dbt staging model | 15 min |
| 3 | **Plan** | Design a mart model before building it | 15 min |
| 4 | **Debug** | Fix a broken SQL query | 15 min |
| 5 | **Agent** | Generate tests and documentation | 15 min |
| 6 | **Multitask** | Propagate a column rename across files | 10 min |
| Bonus | Any | Explore `.cursorrules` for this project | open |

---

## Setup

Open the `labs/day1_lab/dbt_track/` folder in Cursor.  
Enable codebase indexing: Cursor Settings → Indexing & Docs → enable for this workspace.


---

## Exercise 0: Prompt Optimization 

> Complete this exercise in `labs/day1_lab/prompt_optimization/dbt_stream/` before starting Exercise 1.  
> Open `weak_prompts.md` there for full instructions. Return to this folder when done.

---

## Exercise 1: Ask Mode — Understand Before You Touch 

**Goal:** Use Chat (Ask mode) to understand the source data and an existing query before making any changes.

1. Open `source_schema.md`
2. Press `Ctrl+L` → ask:
   ```
   Based on this schema, what data quality issues should I handle
   in a dbt staging model? List them in priority order.
   ```
3. Open `legacy_query.sql`
4. Ask:
   ```
   Explain what this query does in plain English.
   What business question is it answering?
   ```
5. Ask a follow-up:
   ```
   What performance problems does this query have?
   Why would it be slow on a 100 million row table?
   ```

**No code changes yet.** You are in Ask mode — just learning.

---

## Exercise 2: Agent Mode — Generate a Staging Model 

**Goal:** Use Composer (Agent ON) to generate a complete dbt staging model from scratch.


1. Create a new folder `models/` and inside it create a blank file `stg_orders.sql`
2. Press `Ctrl+I`, set mode to **Agent**, then paste:

```
Create a dbt staging model for raw.orders using @source_schema.md.

Requirements:
- Use {{ source('raw', 'orders') }}
- Rename all columns from UPPER_CASE to snake_case
- Cast ORDER_DT (STRING) to DATE
- Cast UPDATED_AT to TIMESTAMP (already TIMESTAMP, just alias it cleanly)
- Derive: is_high_value = true when AMT > 500
- Derive: has_promo = true when PROMO_CODE is not null
- Filter: _FIVETRAN_DELETED = false
- Filter: STATUS != 'TEST'
- Add surrogate key using dbt_utils.generate_surrogate_key(['order_id'])
- Final SELECT: explicit column list, no SELECT *
```

3. Review the diff carefully. Are all the columns handled? Are the casts correct?
4. Accept with `Ctrl+Y`.
5. If something is wrong, reject and add more detail to the prompt.

---

## Exercise 3: Plan Mode — Design Before Building 

**Goal:** Use Chat to design a mart model before writing any SQL.

1. Press `Ctrl+L` and describe what you want to build:

```
I need to build a mart model fct_daily_revenue that aggregates orders to 
the day × region grain.

It should include: total orders, total revenue, avg order value, 
high value order count, completion rate (% of complete orders).

Before I build it:
1. What intermediate models (if any) should I create first?
2. What should the final grain be?
3. Are there any edge cases I should handle (nulls, divisions)?
4. How should I handle the is_high_value column from stg_orders?
```

2. Analyze Cursor's suggestions. Push back if something seems off.

3. Once you agree on the approach, use Agent to build it:

```
Ctrl+I → "Build fct_daily_revenue.sql based on our discussion.
           Use @stg_orders.sql as the source via {{ ref() }}.
           Materialize as a table, partitioned by order_date."
```

---

## Exercise 4: Debug Mode — Fix the Legacy Query 

**Goal:** Use Chat + Debug workflow to diagnose and fix `legacy_query.sql`.

1. Open `legacy_query.sql`
2. Press `Ctrl+L`:

```
This query @legacy_query.sql is running for 45 minutes on a 200M row table.
It's a monthly revenue report that should take < 2 minutes.

Identify the root cause of the performance problems and explain each one.
```

3. After diagnosis, ask Cursor to fix it:

```
Rewrite this query using CTEs to eliminate all performance issues.
Add a comment above each CTE explaining its purpose.
Keep the same output columns and behavior.
```

4. Review the rewrite. Does it produce the same result? Is it clearer?

5. Ask one more question:

```
If I wanted to turn this into a dbt model, what additional changes would I need?
Which parts would use {{ source() }} vs {{ ref() }}?
```

---

## Exercise 5: Agent Mode — Generate Tests and Docs 

**Goal:** Use Composer to automatically generate `schema.yml` for your staging model.

1. Create `models/stg_orders.yml`
2. Press `Ctrl+I`:

```
Generate a dbt schema.yml for @models/stg_orders.sql that includes:
- A model description explaining its purpose (business-friendly language)
- Column descriptions for every column
- Generic tests: unique + not_null on order_sk
- not_null test on order_id and customer_id  
- accepted_values on status: ['pending', 'complete', 'cancelled', 'refunded']
- not_null test on order_date
- A relationships test linking customer_id to dim_customers.customer_id
```

3. Verify the YAML is well-formed.
4. Ask Cursor: "Are there any important tests I'm missing based on the known data quality issues in @source_schema.md?"

> **Your working files at this point:** `models/stg_orders.sql` and `models/stg_orders.yml`

---

## Exercise 6: Multitask Mode — Propagate a Column Rename 

**Goal:** Use Composer (Agent OFF) to update multiple files simultaneously.

The source table is renaming `AMT` to `order_amount`.

1. Press `Ctrl+I`, turn Agent **OFF**
2. Include multiple files and paste:

```
The source column 'AMT' is being renamed to 'order_amount'.
Update all references in:
@models/stg_orders.sql
@models/stg_orders.yml
@models/fct_daily_revenue.sql (if it references this column)

Also rename the derived column 'is_high_value' to 'is_high_value_order' for clarity.
```

3. Review each file's diff individually before accepting.
4. Note: Multitask doesn't run — it proposes changes. You control what gets applied.

---


