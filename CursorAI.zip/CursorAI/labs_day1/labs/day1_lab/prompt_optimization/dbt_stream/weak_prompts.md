# Stream A — Prompt Optimization Exercise

**Duration:** 20 minutes  
**Files to use:** `@orders_schema.md` and `@sample_buggy_model.sql` (in this folder)

---

## Instructions

For each weak prompt below:
1. **Identify** what is missing (2 min)
2. **Rewrite** using the four-part formula — Context + Task + Constraints + Output format (3 min)
3. **Run both** versions in Cursor and compare the output quality (2 min)

---

## Weak Prompt 1 — Too Vague

```
"Write SQL for orders"
```

**What's missing:**
- No SQL dialect specified
- No table structure or column reference
- No output columns or grain (per day? per region? per customer?)
- No filters (what to exclude?)

**Rewrite using:**
- `@orders_schema.md` for table context
- BigQuery dialect
- A specific grain and output columns
- Filters for excluded records

<details>
<summary>Sample strong rewrite (try yours first)</summary>

```
Write a BigQuery SQL query using @orders_schema.md that calculates
total revenue and order count per region per month.

Use CTEs. Partition by order_month using DATE_TRUNC(ORDER_DT, MONTH).
Exclude STATUS = 'TEST', STATUS = 'cancelled', and NULL AMT.
Cast ORDER_DT from STRING to DATE.
Output explicit column names — no SELECT *.
```
</details>

---

## Weak Prompt 2 — No Debug Context

```
"Fix this model"
```

**What's missing:**
- No file attached
- No error message or symptom described
- No expected vs actual behaviour

**Rewrite using:**
- `@sample_buggy_model.sql` attached
- A specific symptom (the query returns far too many rows)
- Expected vs actual behaviour stated

<details>
<summary>Sample strong rewrite (try yours first)</summary>

```
@sample_buggy_model.sql is returning 50× more rows than expected.
The orders table has 100k rows but this query returns 5 million.

Find the root cause and explain why. Then rewrite using CTEs,
fix all SQL anti-patterns, and replace SELECT * with explicit columns.
```
</details>

---

## Weak Prompt 3 — No Test Specification

```
"Add tests"
```

**What's missing:**
- No model or file specified
- No test types listed
- No columns or accepted values mentioned

**Rewrite using:**
- `@orders_schema.md` for column context
- Explicit test types (unique, not_null, accepted_values, relationships)
- Specific columns and expected values

<details>
<summary>Sample strong rewrite (try yours first)</summary>

```
Generate dbt tests for a staging model built on @orders_schema.md.
Add the following to a schema.yml:
- unique + not_null on the surrogate key (order_sk)
- not_null on ORDER_ID and CUST_ID
- accepted_values on STATUS: ['pending', 'complete', 'cancelled', 'refunded']
- relationships test linking CUST_ID to ref('stg_customers').customer_id
Output as valid YAML.
```
</details>

---

## After This Exercise

Switch your Cursor workspace to: `labs/day1_lab/dbt_track/`  
Continue with Exercise 1: Ask Mode.
