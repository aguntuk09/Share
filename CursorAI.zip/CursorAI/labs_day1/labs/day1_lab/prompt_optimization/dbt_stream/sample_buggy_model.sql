-- Sample dbt model for prompt optimization practice.
-- This file has intentional issues — use it for the "Fix this model" prompt exercise.
-- Do NOT copy this into your lab work.

SELECT *
FROM raw.orders o
CROSS JOIN raw.customers c
WHERE o.STATUS != 'TEST'
  AND o.ORDER_DT >= '2024-01-01'
GROUP BY
    SUBSTR(o.ORDER_DT, 1, 7),
    c.REGION
ORDER BY 1, 2
