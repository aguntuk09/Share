# Source Table: `raw.orders`

Practice file for prompt optimization. Use this as `@orders_schema.md` context when rewriting prompts.

## Columns

| Column Name       | Type      | Nullable | Notes |
|-------------------|-----------|----------|-------|
| ORDER_ID          | STRING    | NO       | Primary key. Format: `ORD-XXXXXXXX` |
| CUST_ID           | STRING    | YES      | FK to customer. NULL for guest checkouts |
| ORDER_DT          | STRING    | NO       | Date stored as string: `YYYY-MM-DD` — needs casting |
| UPDATED_AT        | TIMESTAMP | NO       | Last updated |
| AMT               | FLOAT64   | YES      | Order total USD. NULL for draft orders |
| STATUS            | STRING    | NO       | `pending`, `complete`, `cancelled`, `refunded`, `TEST` |
| REGION            | STRING    | YES      | `NORTH`, `SOUTH`, `EAST`, `WEST`, `INTERNATIONAL` |
| CHANNEL           | STRING    | YES      | `organic`, `paid`, `referral`, `direct` |
| ITEM_COUNT        | INTEGER   | YES      | Number of line items |
| _FIVETRAN_DELETED | BOOLEAN   | NO       | Soft delete — exclude when true |

## Known Issues
- `ORDER_DT` is STRING — must cast to DATE
- `STATUS = 'TEST'` rows are QA records — always exclude
- `AMT` is NULL for draft orders
- `_FIVETRAN_DELETED = true` rows must be filtered
