# Prompt Optimization — Exercise 0

**Duration:** 20 minutes  
**When:** Start of the lab session (14:00 – 14:20), before splitting into stream tracks  
**Used by:** Both streams together (then switch to track folder for Exercises 1–6)

---

## Purpose

Practice applying the four-part prompt formula before the main lab exercises. Each stream has its own set of weak prompts, context files, and a rewrite guide.

---

## How to Use

1. **Open this folder in Cursor:** `labs/day1_lab/prompt_optimization/`
2. Go to your stream subfolder:
   - **Stream A (dbt/SQL):** `dbt_stream/` — open `weak_prompts.md`
   - **Stream B (Python):** `python_stream/` — open `weak_prompts.md`
3. Complete the 3 rewrite exercises (see `weak_prompts.md` in your stream)
4. After Exercise 0 is done, **switch your Cursor workspace** to your track lab folder:
   - Stream A: open `labs/day1_lab/dbt_track/`
   - Stream B: open `labs/day1_lab/python_track/`

---

## Folder Structure

```
prompt_optimization/
├── dbt_stream/
│   ├── orders_schema.md       ← source table reference for prompting practice
│   ├── sample_buggy_model.sql ← a SQL file with bugs to practice debug prompts
│   └── weak_prompts.md        ← the 3 weak prompts + rewrite guide
└── python_stream/
    ├── sample_sales.csv       ← small CSV for prompting practice
    ├── sales_snippet.py       ← short broken script to practice debug prompts
    └── weak_prompts.md        ← the 3 weak prompts + rewrite guide
```

---

## The Five-Part Formula (reminder)

| Part | Question |
|------|----------|
| **Role** *(optional)* | Who should Cursor be? → `"You are a senior dbt engineer..."` — include for reviews, architecture, explain to audience |
| **Context** | What am I working with? → use `@filename` |
| **Task** | What do I want? |
| **Constraints** | What rules apply? (dialect, style, libraries) |
| **Output format** | How should the result look? |
