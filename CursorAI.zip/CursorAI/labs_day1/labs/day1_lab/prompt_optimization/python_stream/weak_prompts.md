# Stream B — Prompt Optimization Exercise

**Duration:** 20 minutes  
**Files to use:** `@sales_snippet.py` and `@sample_sales.csv` (in this folder)

---

## Instructions

For each weak prompt below:
1. **Identify** what is missing (2 min)
2. **Rewrite** using the four-part formula — Context + Task + Constraints + Output format (3 min)
3. **Run both** versions in Cursor and compare the output quality (2 min)

---

## Weak Prompt 1 — Too Vague

```
"Write a script to clean data"
```

**What's missing:**
- No input file referenced
- No cleaning rules (what counts as "clean"?)
- No output path or format
- No code quality constraints (type hints? logging?)

**Rewrite using:**
- `@sample_sales.csv` for data context
- Specific cleaning rules (which rows to keep/remove, how to fill nulls)
- Output file path and format
- Code quality requirements

<details>
<summary>Sample strong rewrite (try yours first)</summary>

```
Write a Python script that reads @sample_sales.csv and:
- Removes rows where status is 'refunded' or 'cancelled'
- Fills missing qty with 0
- Fills missing price with the median price for that product
- Calculates revenue = qty * price
- Saves cleaned output to cleaned_sales.csv (index=False)
- Uses logging.info() (not print) to log row count after each step
- Type hints on all function signatures
```
</details>

---

## Weak Prompt 2 — No Error Context

```
"Fix the bug in my code"
```

**What's missing:**
- No file attached
- No error message or symptom
- No expected vs actual behaviour stated

**Rewrite using:**
- `@sales_snippet.py` attached
- A specific symptom (the output summary is always empty)
- Expected vs actual behaviour

<details>
<summary>Sample strong rewrite (try yours first)</summary>

```
@sales_snippet.py runs without any errors but the printed summary
always shows 0 rows.

The input @sample_sales.csv has 8 rows.
Expected: a summary table with one row per region showing total revenue.
Actual: empty DataFrame.

Trace through each function and identify every bug causing the empty output.
List each bug with its line number and the correct fix.
```
</details>

---

## Weak Prompt 3 — Vague Refactor

```
"Refactor this"
```

**What's missing:**
- No file specified
- No goal stated (what should "refactored" look like?)
- No constraints (keep behaviour? add tests?)

**Rewrite using:**
- `@sales_snippet.py` attached
- Explicit changes to make
- Constraint that existing behaviour must be preserved

<details>
<summary>Sample strong rewrite (try yours first)</summary>

```
Refactor @sales_snippet.py:
- Add type hints to every function signature (use pd.DataFrame, Path, str)
- Replace the print() call with logging.info() — add import logging at the top
- Add a if __name__ == '__main__': guard around run()
- Split calculate() into two functions: calculate_revenue() and validate_price()

Keep the existing logic and behaviour unchanged — only change structure and style.
```
</details>

---

## After This Exercise

Switch your Cursor workspace to: `labs/day1_lab/python_track/`  
Continue with Exercise 1: Ask Mode.
