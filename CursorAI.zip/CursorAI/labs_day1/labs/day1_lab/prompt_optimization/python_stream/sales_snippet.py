"""
Short sales summary script for prompt optimization practice.
Contains intentional bugs — use it for the 'Fix the bug' prompt exercise.
Do NOT copy this into your main lab work.
"""
import pandas as pd

def load(path):
    return pd.read_csv(path)

def clean(df):
    # Bug 1: keeps refunded/cancelled instead of removing them
    df = df[df["status"].isin(["refunded", "cancelled"])]
    # Bug 2: drops rows with missing qty instead of filling with 0
    df = df.dropna(subset=["qty"])
    return df

def calculate(df):
    # Bug 3: revenue multiplied by 100 instead of qty
    df["revenue"] = df["price"] * 100
    return df

def summarise(df):
    return df.groupby("region").agg(
        total_revenue=("revenue", "sum"),
        # Bug 4: wrong column name — 'qty' not 'quantity'
        total_units=("quantity", "sum"),
    ).reset_index()

def run():
    df = load("sample_sales.csv")
    df = clean(df)
    df = calculate(df)
    summary = summarise(df)
    print(summary)

if __name__ == "__main__":
    run()
