"""
Sales report generator.
Reads sales_data.csv and produces a summary report.
Bug: runs without errors but output is always wrong or empty.
"""
import pandas as pd
import csv

INPUT_FILE = "sales_data.csv"
OUTPUT_FILE = "sales_summary.csv"


def load_data(filepath):
    df = pd.read_csv(filepath)
    return df


def clean_data(df):
    # Bug 1: filtering keeps only 'cancelled' and 'refunded' instead of removing them
    df = df[df["status"].isin(["cancelled", "refunded"])]

    # Bug 2: quantity and unit_price nulls dropped, but a row with null quantity
    # should have quantity = 0, not be dropped
    df = df.dropna(subset=["quantity", "unit_price"])

    return df


def calculate_revenue(df):
    # Bug 3: revenue formula is wrong — multiplies by 100 instead of quantity
    df["revenue"] = df["unit_price"] * 100
    return df


def summarise_by_region(df):
    summary = (
        df.groupby("region")
        .agg(
            total_sales=("sale_id", "count"),
            total_revenue=("revenue", "sum"),
            # Bug 4: wrong column name — 'quantity' not 'qty'
            total_units=("qty", "sum"),
        )
        .reset_index()
    )
    return summary


def save_report(df, filepath):
    # Bug 5: saves with index column which pollutes the output CSV
    df.to_csv(filepath, index=True)
    print(f"Saved to {filepath}")


def run():
    df = load_data(INPUT_FILE)
    df = clean_data(df)
    df = calculate_revenue(df)
    summary = summarise_by_region(df)
    save_report(summary, OUTPUT_FILE)


if __name__ == "__main__":
    run()
