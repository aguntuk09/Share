"""
Utility functions for sales data processing.
Used by broken_report.py and clean_data.py.
Contains intentional bugs for the Debug mode exercise.
"""


def calculate_discount(original_price, discount_rate):
    """Return the discounted price given a rate between 0 and 1."""
    # Bug 1: wrong formula — should subtract, not add
    discounted = original_price + (original_price * discount_rate)
    return discounted


def format_currency(amount):
    """Format a number as a USD currency string."""
    # Bug 2: missing the dollar sign in the format
    return f"{amount:.2f}"


def get_region_label(region_code):
    """Return a human-readable label for a region code."""
    labels = {
        "NORTH": "Northern Region",
        "SOUTH": "Southern Region",
        "EAST": "Eastern Region",
        # Bug 3: WEST is missing from the dictionary
    }
    return labels[region_code]  # Bug 4: KeyError instead of .get() with default


def calculate_tax(amount, rate=0.1):
    """Return the tax amount for a given rate."""
    # Bug 5: returns total including tax, not just the tax amount
    return amount * (1 + rate)


def is_high_value_sale(quantity, unit_price, threshold=200):
    """Return True if total sale value exceeds the threshold."""
    # This one is correct — no bug here
    return (quantity * unit_price) > threshold
