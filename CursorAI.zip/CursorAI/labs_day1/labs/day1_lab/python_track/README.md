# Lab 1 — Stream B: Python Scripting with Cursor Modes

**Duration:** 2 hours (14:00 – 16:00)  
**Stream:** Support & Automation (Python)

---

## Overview

You will use all five Cursor modes on simple, locally runnable Python scripts. Every exercise runs with `python script.py` — no pipelines, no Airflow, no cloud setup required.

| Exercise | Mode | Task | Time |
|----------|------|------|------|
| 0 | **Prompt Practice** | Rewrite weak prompts using the four-part formula | 15 min |
| 1 | **Ask** | Understand the broken script and sample data | 15 min |
| 2 | **Debug** | Diagnose and fix all bugs in `broken_report.py` | 15 min |
| 3 | **Plan** | Design a clean version before writing it | 10 min |
| 4 | **Agent** | Generate `clean_data.py` from the plan | 15 min |
| 5 | **Multitask** | Fix all bugs in `utils.py` and add type hints | 15 min |
| 6 | **Agent** | Generate unit tests for your functions | 10 min |

---

## Setup

Open `labs/day1_lab/python_track/` in Cursor.  
Python 3.10+ and `pandas` must be installed (`pip install pandas`).  
Verify: `python -c "import pandas; print(pandas.__version__)"` should print a version number.

---

## Exercise 0: Prompt Optimization 

> Complete this exercise in `labs/day1_lab/prompt_optimization/python_stream/` before starting Exercise 1.  
> Open `weak_prompts.md` there for full instructions. Return to this folder when done.

---

## Exercise 1: Ask Mode — Understand the Data 

**Goal:** Use Chat to understand the codebase before touching anything.

1. Open `sales_data.csv`
2. Press `Ctrl+L`:
   ```
   Describe the structure of this CSV. What does each column represent?
   Are there any data quality issues I should be aware of?
   ```
3. Open `broken_report.py`
4. Ask:
   ```
   Explain what @broken_report.py is trying to do step by step.
   What is the expected output?
   ```
5. Ask about `utils.py`:
   ```
   What does each function in @utils.py do?
   Which functions look suspicious or have potential issues?
   ```

**Do not make any changes yet.** Observe and learn.

---

## Exercise 2: Debug Mode — Fix the Broken Script 

**Goal:** Use Chat to diagnose all bugs in `broken_report.py` and `utils.py`.

### Part A: Diagnose `broken_report.py`

1. Press `Ctrl+L`:
   ```
   @broken_report.py runs without throwing an error but the output
   sales_summary.csv always contains 0 or very few rows.
   
   Trace through each function step by step.
   What is wrong with the filtering logic in clean_data()?
   What other bugs can you find?
   List every bug with its line number and the correct fix.
   ```

2. Once you have the list, use `Ctrl+I` to apply the fixes:
   ```
   Fix all the bugs you identified in @broken_report.py
   ```

3. Run the script: `python broken_report.py`  
   Verify: `sales_summary.csv` should now have 4 rows (one per region) with sensible numbers.

### Part B: Diagnose `utils.py`

```
Ctrl+L → "Find all the bugs in @utils.py.
           For each function, is the logic correct?
           Test the discount calculation: calculate_discount(100, 0.2) should return 80.
           Is get_region_label safe to call with any valid region code?"
```

---

## Exercise 3: Plan Mode — Design Before You Build

**Goal:** Use Chat to design a clean, well-structured replacement for `broken_report.py` before writing any code.

1. Press `Ctrl+L`:
   ```
   I want to rewrite broken_report.py as a clean script called clean_data.py.
   
   The script should:
   - Read sales_data.csv
   - Remove rows with status = 'cancelled' or 'refunded'
   - Fill missing quantity with 0
   - Fill missing unit_price with the median price for that product
   - Calculate revenue = quantity * unit_price
   - Produce two outputs:
     a) cleaned_sales.csv — the cleaned row-level data
     b) regional_summary.csv — total sales, revenue, and units per region
   
   Before I build it:
   - What functions should I create? (one per responsibility)
   - How should I handle the median fill — should it be in a separate function?
   - What logging statements would be most useful?
   ```

2. Discuss and agree on the structure with Cursor.
3. Ask:
   ```
   Summarise the final agreed structure as a function list with signatures
   so I can hand it to the Agent to implement.
   ```

---

## Exercise 4: Agent Mode — Implement the Plan 

**Goal:** Use Composer (Agent ON) to build `clean_data.py` based on your plan.

1. Create a new file `clean_data.py`
2. Press `Ctrl+I` (Agent ON):
   ```
   Implement clean_data.py based on the design we discussed.
   
   Structure:
   - read_data(filepath: Path) -> pd.DataFrame
   - filter_valid_sales(df: pd.DataFrame) -> pd.DataFrame
   - fill_missing_values(df: pd.DataFrame) -> pd.DataFrame
   - calculate_revenue(df: pd.DataFrame) -> pd.DataFrame
   - summarise_by_region(df: pd.DataFrame) -> pd.DataFrame
   - save_outputs(df: pd.DataFrame, summary: pd.DataFrame, output_dir: Path) -> None
   - run(input_path: Path, output_dir: Path) -> None
   
   Requirements:
   - Type hints on all functions
   - logging module (not print)
   - Log row counts at each step
   - Entry point: if __name__ == "__main__": with argparse for input and output paths
   - index=False when saving CSVs
   ```

3. Review the generated code. Run it: `python clean_data.py`
4. If it fails, use Debug mode to fix it:
   ```
   Ctrl+L → "This script threw [paste error]. The file is @clean_data.py. What went wrong?"
   ```

---

## Exercise 5: Multitask Mode — Fix `utils.py` and Add Type Hints

**Goal:** Use Composer (Agent OFF) to fix multiple issues across `utils.py` at once.

1. Press `Ctrl+I`, Agent **OFF**:
   ```
   In @utils.py:
   1. Fix all the bugs I found in the debug exercise
   2. Add type hints to every function signature
   3. Add a one-line docstring to any function missing one
   4. Change get_region_label to use .get() with a default of "Unknown Region"
      so it never raises a KeyError
   ```

2. Review the diff — every function should be changed.
3. After accepting, run a quick sanity check in `Ctrl+L`:
   ```
   Does @utils.py now look correct?
   Would calculate_discount(100, 0.2) return 80.0?
   Would get_region_label("WEST") return "Western Region"?
   ```

---

## Exercise 6: Agent Mode — Generate Unit Tests

**Goal:** Use Composer (Agent ON) to write pytest unit tests for `utils.py`.

1. Create `test_utils.py`
2. Press `Ctrl+I` (Agent ON):
   ```
   Write pytest unit tests for every function in @utils.py.
   
   For each function include:
   - A happy path test with expected output
   - An edge case (zero, empty string, boundary value)
   - For calculate_discount: test that a 20% discount on 100 returns 80.0
   - For get_region_label: test that all 4 valid codes work, and an unknown code returns "Unknown Region"
   - For is_high_value_sale: test the boundary at exactly the threshold
   
   Use pytest fixtures where they reduce repetition.
   ```

3. Run: `python -m pytest test_utils.py -v`  
   All tests should pass (assuming you fixed the bugs in Exercise 5).

---


