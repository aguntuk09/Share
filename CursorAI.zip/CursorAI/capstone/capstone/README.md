# Capstone: TelcoInsight Analytics Platform

**Type:** Take-home assignment  
**Submission deadline:** [To be announced by facilitator]  
**Estimated effort:** 4–6 hours  
**Total points:** 100  
**Evaluation:** See `evaluation_rubric.md`

---

## Background

You've just joined a telecom company's Data Engineering team. The company collects real-time Call Detail Records (CDRs) from its network infrastructure and stores raw operational data in a cloud data warehouse.

Your manager has asked you to build the first analytics layer on top of three raw source tables. The goal is to enable the BI team to analyse subscriber usage, call behaviour, and plan performance.

**Your task:** Build a complete, well-tested, documented analytics layer for the same business problem — using the tools and techniques from this training with Cursor as your development assistant.

---

## Two Streams — Same Business Problem, Different Technology

Both streams solve the same problem. Choose the track that matches your role:

| Stream | Technology | Who should choose this |
|--------|-----------|----------------------|
| **Stream A — dbt/SQL** | SQL models in dbt (BigQuery) | Data Engineers working with dbt |
| **Stream B — Python** | Python scripts with pandas | Support & Automation engineers |

The source data, business requirements, and evaluation criteria are equivalent across both streams.

---

## Source Data

Schema details are in `source_schemas.md`.

| Table / File | Description |
|--------------|-------------|
| `raw.call_records` / `sample_data/call_records_sample.csv` | One row per call/SMS/data session |
| `raw.subscribers` / `sample_data/subscribers_sample.csv` | One row per subscriber (current state) |
| `raw.plans` / `sample_data/plans_sample.csv` | Product catalog of available plans |

**Stream A** references the database tables (`raw.call_records` etc.) via `{{ source() }}` macros.  
**Stream B** reads from the CSV files in `sample_data/` using pandas.

---

## Deliverables

### Stream A — dbt/SQL

| # | Deliverable | Points | Files Expected |
|---|------------|--------|----------------|
| 1 | Staging models (all 3 sources) | 20 | `stg_call_records.sql`, `stg_subscribers.sql`, `stg_plans.sql` |
| 2 | Mart model: `fct_daily_usage` | 25 | `fct_daily_usage.sql` |
| 3 | dbt tests — schema.yml for all models | 20 | `stg_call_records.yml`, `stg_subscribers.yml`, `stg_plans.yml`, `fct_daily_usage.yml` |
| 4 | Documentation + `.cursorrules` | 10 | Column descriptions in YAMLs + `.cursorrules` |
| **Bonus** | Cursor dbt-helper plugin | 25 | `.cursor-plugin/plugin.json` + rules + skill + hook |

### Stream B — Python

| # | Deliverable | Points | Files Expected |
|---|------------|--------|----------------|
| 1 | Staging scripts (all 3 sources) | 20 | `stg_call_records.py`, `stg_subscribers.py`, `stg_plans.py` |
| 2 | Mart script: `fct_daily_usage.py` | 25 | `fct_daily_usage.py` |
| 3 | Unit tests | 20 | `test_staging.py`, `test_fct_daily_usage.py` |
| 4 | Documentation + `.cursorrules` | 10 | Docstrings + README + `.cursorrules` |
| **Bonus** | Cursor python-helper plugin | 25 | `.cursor-plugin/plugin.json` + rules + skill + hook |

---

## Deliverable Specifications

### Stream A: Staging Models (SQL)

Each staging model must:
- Use `{{ source('raw', 'table_name') }}` — no bare table strings
- Rename all columns from `UPPER_CASE` to `snake_case`
- Cast columns to appropriate types (dates, timestamps, booleans)
- Filter out `CALL_TYPE = 'TEST'` / `SUBSCRIBER_STATUS = 'TEST'` records
- Filter out `_FIVETRAN_DELETED = true` rows
- Exclude PII columns (`FIRST_NM`, `LAST_NM`) from `stg_subscribers`
- Add a surrogate key using `dbt_utils.generate_surrogate_key()`

### Stream B: Staging Scripts (Python)

Each staging script must:
- Read from the corresponding CSV in `sample_data/`
- Rename all columns from `UPPER_CASE` to `snake_case`
- Cast columns to correct Python types (datetime, float, bool)
- Filter out `CALL_TYPE = 'TEST'` / `SUBSCRIBER_STATUS = 'TEST'` records
- Filter out `_FIVETRAN_DELETED = True` rows
- Exclude PII columns (`FIRST_NM`, `LAST_NM`) from `stg_subscribers`
- Save cleaned output as a new CSV (e.g., `output/stg_call_records.csv`)
- Use `logging` (not `print()`), type hints on all functions, `index=False` when saving
- Entry point: `if __name__ == "__main__":` with `argparse`

---

### Stream A: `fct_daily_usage` Mart Model (SQL)

Aggregate `stg_call_records` to the **subscriber × call_date grain**.

**Required columns:**

| Column | Logic |
|--------|-------|
| `usage_id` | Surrogate key on (subscriber_id, call_date) |
| `subscriber_id` | FK to stg_subscribers |
| `call_date` | DATE |
| `total_calls` | Count of all calls |
| `total_call_duration_seconds` | Sum of duration_secs |
| `voice_calls` | Count where call_type = 'voice' |
| `data_sessions` | Count where call_type = 'data' |
| `sms_sent` | Count where call_type = 'sms' |
| `dropped_calls` | Count where call_status = 'dropped' |
| `drop_rate` | dropped_calls / total_calls (handle divide-by-zero) |
| `network_4g_calls` | Count where network_type IN ('4G', '5G') |

**Config:** Materialise as a table, partitioned by `call_date`.

### Stream B: `fct_daily_usage.py` Mart Script (Python)

Read the staged call records output and aggregate to the **subscriber × call_date grain**.

Produce the same 11 columns listed above (as a pandas DataFrame). Save to `output/fct_daily_usage.csv`.

Requirements:
- One function per aggregation step
- `drop_rate` must handle division by zero (use `numpy.where` or fill 0 when `total_calls = 0`)
- Type hints on all function signatures
- Logging at each step with row count

---

### Stream A: Tests (schema.yml)

For each model, provide a `schema.yml` with:
- Model-level description (business-friendly, 1–2 sentences)
- Column descriptions for every column
- `unique` + `not_null` on the surrogate/primary key
- `not_null` on all FK columns
- `accepted_values` on at least 3 status/type columns
- At least one `relationships` test on a FK in `fct_daily_usage`

### Stream B: Unit Tests (pytest)

Write pytest tests covering:
- **Staging functions:** correct column renaming, type casting, PII exclusion, TEST record filtering
- **Mart aggregation:** correct grain (one row per subscriber per day), correct column totals, `drop_rate` at zero and non-zero `total_calls`
- **Edge cases:** empty input, all-dropped calls, null duration values

Minimum: 8 test functions across the two test files.

---

### Both Streams: Documentation + `.cursorrules`

**`.cursorrules`** — configure for this project:
- Stream A: BigQuery dialect, dbt conventions, test requirements
- Stream B: Python standards, type hints, logging, no print

**Documentation:**
- Stream A: business-friendly descriptions on all YAML columns
- Stream B: docstrings on all functions, a `README.md` explaining how to run the scripts

---

### Bonus: Cursor Plugin (both streams)

Package the Cursor customisations from Day 2 lab into a distributable plugin:

```
cursor-plugins/
└── dbt-helper/  OR  python-helper/
    ├── .cursor-plugin/plugin.json    ← manifest
    ├── rules/                         ← Always rule
    ├── skills/                        ← Skill (staging model or script generation)
    ├── hooks.json + hooks/            ← Hook (SQL validator or Python style check)
    └── README.md
```

---

## Suggested Cursor Workflow

**Stream A — starting prompts:**
```
"Using @source_schemas.md, create a dbt staging model for raw.call_records.
 Apply these conventions: snake_case columns, {{ source() }} macro, surrogate key,
 filter TEST records and _FIVETRAN_DELETED = true. No PII columns."

"Create a dbt mart model fct_daily_usage aggregating @stg_call_records.sql
 to the subscriber-day grain. Required columns: [see spec above].
 Materialise as a table partitioned by call_date."
```

**Stream B — starting prompts:**
```
"Using @source_schemas.md and @sample_data/call_records_sample.csv,
 write a Python staging script stg_call_records.py that:
 - Reads the CSV, renames UPPER_CASE columns to snake_case
 - Filters CALL_TYPE = 'TEST' and _FIVETRAN_DELETED rows
 - Casts CALL_START_TS string to datetime
 - Saves cleaned output to output/stg_call_records.csv
 - Uses logging, type hints, argparse entry point."

"Write fct_daily_usage.py that reads @output/stg_call_records.csv
 and aggregates to subscriber × call_date grain.
 Required columns: [see spec above]. Handle divide-by-zero in drop_rate."
```

---

## What Will Be Evaluated

See `evaluation_rubric.md` for full scoring.

Both streams are assessed on equivalent criteria:
- **Correctness** — does the code produce the right output?
- **Standards** — are naming conventions, types, and structure correct?
- **Test coverage** — are tests meaningful, not just boilerplate?
- **Code quality** — no hardcoded values, no SELECT *, no bare `except`
- **Documentation** — could a new team member understand this without explanation?

---

## Submission

See `submission_guide.md` for how to package and submit your work.
