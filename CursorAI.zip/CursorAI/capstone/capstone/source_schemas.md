# Capstone Source Schemas

These three tables are loaded into the warehouse from operational systems. Treat them as raw — they contain dirty data, inconsistent naming, and fields that need casting.

---

## Table 1: `raw.call_records`

**Description:** One row per call attempt, SMS, or data session. Loaded every 15 minutes from the network mediation layer via Kafka → Fivetran.

**Volume:** ~50 million rows per day, ~1.5 billion per month.

| Column | Type | Nullable | Description |
|--------|------|----------|-------------|
| CALL_ID | STRING | NO | Primary key. Format: `CDR-YYYYMMDD-XXXXXXXX` |
| CALLER_MSISDN | STRING | YES | Calling subscriber's phone number (E.164 format). NULL for incoming-only records |
| CALLEE_MSISDN | STRING | YES | Called party's number. NULL for data sessions |
| CALL_START_TS | STRING | NO | Call start timestamp as STRING: `YYYY-MM-DD HH:MM:SS` |
| DURATION_SECS | INTEGER | YES | Call/session duration in seconds. NULL for failed/dropped before connect |
| CALL_TYPE | STRING | NO | One of: `voice`, `data`, `sms`, `mms`, `TEST` |
| CALL_STATUS | STRING | NO | One of: `completed`, `dropped`, `failed`, `busy`, `no_answer` |
| NETWORK_TYPE | STRING | YES | One of: `2G`, `3G`, `4G`, `5G`. NULL if network could not be determined |
| REGION_CODE | STRING | YES | 2-char region code: `N1`, `S1`, `E1`, `W1`, `INTL`. NULL for unresolvable location |
| CELL_TOWER_ID | STRING | YES | Tower identifier. NULL for VoIP/roaming calls |
| ROAMING_FLAG | INTEGER | NO | 0 = domestic, 1 = roaming |
| CHARGE_AMOUNT | FLOAT64 | YES | Amount charged for this call in USD. NULL for flat-rate plan subscribers |
| _FIVETRAN_DELETED | BOOLEAN | NO | Soft delete flag |
| _FIVETRAN_SYNCED | TIMESTAMP | NO | Fivetran sync timestamp |

**Known Issues:**
- `CALL_TYPE = 'TEST'` rows are injected by the network testing team — must be excluded
- `CALL_START_TS` is STRING and must be cast to TIMESTAMP
- `DURATION_SECS` can be 0 for SMS — this is valid, not null
- `CALLER_MSISDN` and `CALLEE_MSISDN` sometimes contain leading/trailing spaces
- Duplicate `CALL_ID` values appear within the same 15-min window during peak load (keep latest `_FIVETRAN_SYNCED`)
- `ROAMING_FLAG` uses integer (0/1) not boolean — cast appropriately

---

## Table 2: `raw.subscribers`

**Description:** Current snapshot of all subscribers. Full refresh daily from the CRM system. One row per subscriber MSISDN.

**Volume:** ~2 million rows (current active + recently churned).

| Column | Type | Nullable | Description |
|--------|------|----------|-------------|
| MSISDN | STRING | NO | Primary key. Subscriber's phone number in E.164 format |
| PLAN_ID | STRING | YES | FK to `raw.plans`. NULL for legacy subscribers on sunset plans |
| FIRST_NM | STRING | YES | First name — PII, do not expose in marts |
| LAST_NM | STRING | YES | Last name — PII, do not expose in marts |
| ACTIVATION_DT | STRING | NO | Account activation date as STRING: `YYYY-MM-DD` |
| SUBSCRIBER_STATUS | STRING | NO | One of: `active`, `suspended`, `churned`, `pending_activation`, `TEST` |
| MONTHLY_SPEND_USD | FLOAT64 | YES | Average monthly spend last 3 months. NULL for new subscribers (<3 months old) |
| DATA_ALLOWANCE_GB | FLOAT64 | YES | Monthly data allowance. NULL for unlimited plans |
| CONTRACT_TYPE | STRING | YES | One of: `prepaid`, `postpaid`, `corporate`. NULL for migrated legacy accounts |
| LAST_TOPUP_DT | STRING | YES | Last top-up date (prepaid only). NULL for postpaid |
| CHURN_RISK_SCORE | FLOAT64 | YES | Model-generated churn probability (0.0–1.0). Refreshed weekly. Can be NULL if model hasn't run |
| REGION_CODE | STRING | YES | Home region code: `N1`, `S1`, `E1`, `W1` |
| _FIVETRAN_DELETED | BOOLEAN | NO | Soft delete flag |
| _FIVETRAN_SYNCED | TIMESTAMP | NO | Fivetran sync timestamp |

**Known Issues:**
- `FIRST_NM` and `LAST_NM` are PII — **must NOT appear in any mart model**
- `ACTIVATION_DT` and `LAST_TOPUP_DT` are STRING — cast to DATE
- `SUBSCRIBER_STATUS = 'TEST'` rows are QA accounts — exclude
- `_FIVETRAN_DELETED = true` rows must be filtered out
- `MONTHLY_SPEND_USD` is NULL for new subscribers — handle NULLs in aggregations
- `DATA_ALLOWANCE_GB` being NULL means unlimited — document this in column description

---

## Table 3: `raw.plans`

**Description:** Product catalog of available subscriber plans. Small table, updated manually when plans change. Full refresh weekly.

**Volume:** ~200 rows.

| Column | Type | Nullable | Description |
|--------|------|----------|-------------|
| PLAN_ID | STRING | NO | Primary key. Format: `PLN-XXXX` |
| PLAN_NM | STRING | NO | Human-readable plan name (e.g., "Unlimited Plus 5G") |
| PLAN_CATEGORY | STRING | NO | One of: `basic`, `standard`, `premium`, `enterprise` |
| MONTHLY_PRICE_USD | FLOAT64 | NO | Monthly subscription price |
| DATA_ALLOWANCE_GB | FLOAT64 | YES | Included data in GB. NULL = unlimited |
| VOICE_MINUTES | INTEGER | YES | Included voice minutes. NULL = unlimited |
| SMS_INCLUDED | INTEGER | YES | Included SMS count. NULL = unlimited |
| ROAMING_INCLUDED | BOOLEAN | NO | Whether international roaming is included |
| PLAN_STATUS | STRING | NO | One of: `active`, `deprecated`, `sunset` |
| EFFECTIVE_DT | STRING | NO | Date plan became available: `YYYY-MM-DD` |
| END_DT | STRING | YES | Date plan was retired. NULL = currently available |

**Known Issues:**
- `EFFECTIVE_DT` and `END_DT` are STRING — cast to DATE
- `PLAN_STATUS = 'deprecated'` and `'sunset'` plans still have subscribers — do **not** filter them out; they are valid FKs
- `DATA_ALLOWANCE_GB`, `VOICE_MINUTES`, `SMS_INCLUDED` being NULL means unlimited — document this in descriptions
- `PLAN_NM` has trailing whitespace in some rows — trim it

---

## Relationships

```
raw.subscribers.PLAN_ID  →  raw.plans.PLAN_ID
raw.call_records.CALLER_MSISDN  →  raw.subscribers.MSISDN
```

Note: Not all `CALLER_MSISDN` values will match a subscriber (guest SIMs, roaming visitors, etc.). The FK relationship is expected to have ~5% non-matching rows.
