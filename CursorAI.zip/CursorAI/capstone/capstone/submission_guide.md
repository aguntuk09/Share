# Capstone Submission Guide

---

## Submission Deadline

**Deadline:** 7th July,2026 (EoD)  

---

## Choose Your Stream

Submit work for the stream that matches your role:

| Stream | Technology | Submit |
|--------|-----------|--------|
| **Stream A — dbt/SQL** | SQL models + schema.yml | See folder structure below |
| **Stream B — Python** | Python scripts + pytest tests | See folder structure below |

---

## Folder Structure to Submit

### Stream A — dbt/SQL

```
<your_name>_telcoinsight_dbt/
│
├── .cursorrules                              ← Required (Deliverable 4)
│
├── models/
│   ├── staging/
│   │   ├── stg_call_records.sql              ← Deliverable 1
│   │   ├── stg_call_records.yml              ← Deliverable 3
│   │   ├── stg_subscribers.sql               ← Deliverable 1
│   │   ├── stg_subscribers.yml               ← Deliverable 3
│   │   ├── stg_plans.sql                     ← Deliverable 1
│   │   └── stg_plans.yml                     ← Deliverable 3
│   └── marts/
│       ├── fct_daily_usage.sql               ← Deliverable 2
│       └── fct_daily_usage.yml               ← Deliverable 3
│
└── cursor-plugins/                           ← Bonus (optional)
    └── dbt-helper/
        ├── .cursor-plugin/plugin.json
        ├── rules/
        ├── skills/
        ├── hooks.json
        └── hooks/
```

### Stream B — Python

```
<your_name>_telcoinsight_python/
│
├── .cursorrules                              ← Required (Deliverable 4)
├── README.md                                 ← Required (Deliverable 4)
│
├── staging/
│   ├── stg_call_records.py                   ← Deliverable 1
│   ├── stg_subscribers.py                    ← Deliverable 1
│   └── stg_plans.py                          ← Deliverable 1
│
├── marts/
│   └── fct_daily_usage.py                    ← Deliverable 2
│
├── tests/
│   ├── test_staging.py                       ← Deliverable 3
│   └── test_fct_daily_usage.py               ← Deliverable 3
│
└── cursor-plugins/                           ← Bonus (optional)
    └── python-helper/
        ├── .cursor-plugin/plugin.json
        ├── rules/
        ├── skills/
        ├── hooks.json
        └── hooks/
```

---

## Pre-Submission Checklist

### Stream A — dbt/SQL

**Staging models**
- [ ] All 3 `.sql` files present
- [ ] All 3 `.yml` files present
- [ ] `{{ source('raw', ...) }}` used (not raw table strings)
- [ ] `FIRST_NM`, `LAST_NM` absent from `stg_subscribers.sql`
- [ ] Date/timestamp STRING columns cast correctly
- [ ] `CALL_TYPE = 'TEST'` and `_FIVETRAN_DELETED = true` rows filtered

**Mart model**
- [ ] `fct_daily_usage.sql` present
- [ ] All 11 required columns present
- [ ] `{{ ref() }}` used for all staging references
- [ ] Partitioned by `call_date`
- [ ] `drop_rate` handles divide-by-zero

**Tests**
- [ ] All 4 `.yml` files have model-level descriptions
- [ ] All columns have descriptions
- [ ] `unique` + `not_null` on every surrogate key
- [ ] At least one `relationships` test
- [ ] At least 3 uses of `accepted_values`

**Documentation**
- [ ] `.cursorrules` present and project-specific (not a copy-paste)
- [ ] Descriptions are business-friendly

---

### Stream B — Python

**Staging scripts**
- [ ] All 3 `.py` scripts present and run without errors
- [ ] Read from `sample_data/*.csv`
- [ ] `FIRST_NM`, `LAST_NM` absent from `stg_subscribers.py` output
- [ ] Date/timestamp strings converted to datetime
- [ ] `CALL_TYPE = 'TEST'` and `_FIVETRAN_DELETED = True` rows filtered
- [ ] Type hints on all functions, `logging` not `print()`, `index=False` in CSV saves

**Mart script**
- [ ] `fct_daily_usage.py` present and runs without errors
- [ ] All 11 required columns present in output CSV
- [ ] Grain is correct (one row per subscriber per day)
- [ ] `drop_rate` handles division by zero

**Tests**
- [ ] Both test files present
- [ ] `python -m pytest tests/ -v` exits 0 (all tests pass)
- [ ] At least 8 test functions across both files
- [ ] Tests check actual values, not just `assert True`

**Documentation**
- [ ] `.cursorrules` present and project-specific
- [ ] `README.md` explains how to install dependencies and run each script
- [ ] All functions have docstrings

---

## Submission Method

**Email**  
Send your ZIP to: harvinder.bajaj@capgemini.com  
Subject: `[Cursor Capstone] <Your Name> — TelcoInsight <Stream A or B>`


---

## Evaluation Process

1. Facilitator reviews submissions against `evaluation_rubric.md`
2. Scores returned within 7 business days of the deadline
3. All participants receive written feedback with their score breakdown

---

## Questions

Ask in the training Teams channel, or email the facilitator directly.  
Using `@docs` or `@web` in Cursor to look up documentation is encouraged and expected.
