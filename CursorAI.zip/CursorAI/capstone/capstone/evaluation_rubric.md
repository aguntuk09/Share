# Capstone Evaluation Rubric

**Total: 100 points (+ 25 bonus)**  
**Both streams assessed on equivalent criteria — same points, same bands.**

| Score | Band | Meaning |
|-------|------|---------|
| 90–100 | Excellent | All deliverables complete and high quality. Demonstrates confident Cursor usage. |
| 75–89 | Proficient | All deliverables present. Minor gaps in quality or coverage. |
| 60–74 | Satisfactory | Most deliverables present. Noticeable gaps in tests or documentation. |
| < 60 | Needs Improvement | Missing key deliverables or significant correctness issues. |

---

## Deliverable 1: Staging Layer — 20 points

| Criterion | Stream A (dbt/SQL) | Stream B (Python) | Points |
|-----------|-------------------|------------------|--------|
| All 3 files present and valid | `.sql` files with no syntax errors | `.py` scripts that run without import errors | 4 |
| Correct source reference | `{{ source('raw', ...) }}` used, not bare table strings | Reads from `sample_data/*.csv`, not hardcoded data | 3 |
| Column renaming and type casting | `UPPER_CASE` → `snake_case`, dates/timestamps/booleans cast correctly | Same renames + Python type casting (datetime, float, bool) | 4 |
| Data quality filters applied | `CALL_TYPE != 'TEST'`, `_FIVETRAN_DELETED = false` | Same filters in pandas | 5 |
| PII excluded from subscribers | `FIRST_NM`, `LAST_NM` absent from `stg_subscribers` | Same — not in output CSV | 4 |

**Common deductions (both streams):**
- Missing TEST filter: −2
- PII columns present in subscribers output: −4
- Missing type casts on date/timestamp columns: −2 per file

---

## Deliverable 2: `fct_daily_usage` — 25 points

| Criterion | Stream A (dbt/SQL) | Stream B (Python) | Points |
|-----------|-------------------|------------------|--------|
| Correct grain — one row per subscriber per day | Verify with a GROUP BY check | DataFrame has unique (subscriber_id, call_date) pairs | 5 |
| All 11 required columns present with correct logic | Check each column against spec | Same check on DataFrame columns | 10 |
| Correct reference to staging layer | `{{ ref('stg_call_records') }}` used | Reads from `output/stg_call_records.csv` | 4 |
| Output config correct | `materialized='table'`, partitioned by `call_date` | Saves to `output/fct_daily_usage.csv`, `index=False` | 3 |
| `drop_rate` handles divide-by-zero | `NULLIF(total_calls, 0)` or `SAFE_DIVIDE()` | `numpy.where(total_calls > 0, ...)` or equivalent | 3 |

**Common deductions (both streams):**
- Incorrect grain (wrong GROUP BY / missing subscriber dimension): −10
- `drop_rate` causes division by zero: −3
- Missing columns from the required list: −1 per column

---

## Deliverable 3: Tests — 20 points

### Stream A — schema.yml tests

| Criterion | Points | How to Assess |
|-----------|--------|---------------|
| All 4 schema.yml files present with model descriptions | 4 | Files exist, non-empty business-friendly description |
| Column descriptions on every column | 4 | No blank descriptions |
| `unique` + `not_null` on every surrogate/primary key | 4 | Applied in all 4 models |
| `accepted_values` on at least 3 status/type columns | 4 | e.g., `call_type`, `call_status`, `subscriber_status` |
| At least one `relationships` test on a FK | 4 | e.g., `fct_daily_usage.subscriber_id` → `stg_subscribers` |

### Stream B — pytest unit tests

| Criterion | Points | How to Assess |
|-----------|--------|---------------|
| Test files present and runnable (`pytest` passes) | 4 | `python -m pytest` exits 0 |
| Staging tests: renaming, filtering, PII exclusion, types | 6 | At least one test per transform concern |
| Mart tests: grain, column values, drop_rate edge cases | 6 | Tests for grain uniqueness, zero divide, null duration |
| At least 8 test functions with meaningful assertions | 4 | Not just `assert True` — checks actual values |

---

## Deliverable 4: Documentation + `.cursorrules` — 10 points

| Criterion | Stream A | Stream B | Points |
|-----------|----------|----------|--------|
| `.cursorrules` present and project-specific | BigQuery, dbt conventions, test requirements | Python standards, type hints, logging, pathlib | 3 |
| `.cursorrules` tailored (not a copy-paste) | Mentions telecom domain specifics | Same | 4 |
| Documentation is business-friendly | YAML column descriptions readable by a BI analyst | Docstrings + README — new team member could run the scripts | 3 |

---

## Bonus: Cursor Plugin — 25 points

Assessed identically for both streams.

| Criterion | Points | How to Assess |
|-----------|--------|---------------|
| `.cursor-plugin/plugin.json` manifest present and valid | 5 | `name` field present, matches folder name |
| Always rule (`.mdc`) enforcing project standards | 5 | Not a blank file — contains project-specific standards |
| Skill (`SKILL.md`) with workflow, template/reference, and script reference | 8 | SKILL.md references bundled assets; not just a checklist |
| Hook (`hooks.json` + script) firing on correct file type | 7 | `hooks.json` present; script reads JSON stdin; validates/checks correct extension |

---

## Evaluator Notes

### What "Cursor usage" means
Participants do not submit Cursor chat logs. Quality of output is the signal: correct conventions, meaningful tests, and business-friendly documentation are the fingerprints of good AI-assisted development with human review.

### Stream equivalence
When comparing Stream A and Stream B submissions, the business logic should be equivalent — both produce the same 11 columns for `fct_daily_usage`, both apply the same filters, both exclude PII. Technology choice does not affect the score.

### Handling borderline cases
- Test coverage is the primary tiebreaker — tests reveal understanding more clearly than generated code alone
- A script/model that runs but has no tests is riskier than a simpler one with full tests
- If a submission looks rushed, ask the participant to walk through their work verbally

### Bonus scoring
The bonus plugin is assessed independently. A weak core submission with an excellent plugin does not improve the core score — the 25 bonus points add on top.
